# Noxy Dashboard

A read-only web dashboard for the Noxy Discord bot. It reads `levidatabase.json`
and has two parts:

- **Member dashboard** (`/`): members log in with Discord and manage their servers
  (members with Manage Server), see their own level and XP, and their analysis for each
  server.
- **Staff dashboard** (`/admin/`): servers, moderation, commands, the economy and
  database health. It is protected by a token.

It is written in C++17 with a plain HTML/CSS/JS front end. It never writes to the
database, so it cannot change the bot's data.

## Build

Needs CMake 3.16+, a C++17 compiler and OpenSSL (for Discord login). The other
dependencies are vendored in `third_party/`.

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
ctest --test-dir build        # runs the aggregation tests
```

## Run

From the folder that holds the bot's `levidatabase.json`:

```bash
./build/noxy-dashboard --db /path/to/noxy-v7/levidatabase.json
```

Then open <http://127.0.0.1:8080>. Without Discord settings, the member page
shows "Login not set up yet". The staff page at `/admin/` still works.

| Option | Meaning |
|---|---|
| `--db <file>` | Path to `levidatabase.json` (or env `NOXY_DB`) |
| `--web <dir>` | UI folder, which holds `member/` and `admin/` (defaults to `web/`) |
| `--host <addr>` | Listen address, default `127.0.0.1` |
| `--port <n>` | Port, default `8080` |

Server settings also need the bot connection. See **Server settings** below.

## Member login (Discord)

1. In the [Discord Developer Portal](https://discord.com/developers/applications),
   open your application, go to **OAuth2**, and add this redirect URI:
   `https://YOUR-DOMAIN/auth/callback` (for local testing,
   `http://127.0.0.1:8080/auth/callback`).
2. Copy the **Client Secret**. The app only needs the `identify` scope.
3. Start the dashboard with these environment variables:

```bash
export NOXY_DISCORD_CLIENT_SECRET='paste-the-secret-here'
export NOXY_PUBLIC_URL='https://YOUR-DOMAIN'
./build/noxy-dashboard --db /path/to/levidatabase.json --host 0.0.0.0
```

| Variable | Meaning |
|---|---|
| `NOXY_DISCORD_CLIENT_SECRET` | Required to enable login. Keep it out of the code and the repository. |
| `NOXY_DISCORD_CLIENT_ID` | Defaults to the Noxy application ID. |
| `NOXY_PUBLIC_URL` | The public address. The redirect URI is this plus `/auth/callback`. |

How it works: the browser goes to Discord, Discord sends back a one-time code,
and the server trades it for the member's basic profile. The client secret is
only sent server to server. The session is an HttpOnly cookie that lasts 7 days.
Sessions are kept in memory, so members log in again after a restart.

Use HTTPS in production (for example, a reverse proxy with Caddy or nginx). Discord
requires it for a public redirect URI, and the session cookie is marked `Secure`
when the address is HTTPS.

## Staff dashboard and token

The staff API and `/admin/` always require a token. Set `NOXY_DASHBOARD_TOKEN` to
choose it. If you don't, the server makes a random token for each run and prints it
once at startup. The browser asks for the token once per tab, and it is kept in
`sessionStorage`. The token is read from the environment, not the command line, so
it does not show up in shell history.

The staff dashboard shows member IDs, warning reasons and moderation history.
Use `--host 0.0.0.0` only with a token set, and keep it behind HTTPS.

## Server settings (members with Manage Server)

Members can change the settings of servers where they have Manage Server (or Administrator,
or are the owner). The dashboard does not write to the database. It forwards each change to
the Noxy bot's internal settings API, which runs on the same machine and checks the member's
permission again on every call. The bot validates each field and refuses anything it does
not allow, such as a channel outside the server.

Set the same key in both the bot and the dashboard. The key must be at least 24 characters:

```bash
export NOXY_INTERNAL_KEY='a-long-random-string-of-24-plus-characters'   # same value for both
export NOXY_BOT_API='http://127.0.0.1:8787'                               # optional, the default
```

The bot's API only listens on `127.0.0.1`, and the dashboard refuses any address other than
`127.0.0.1` or `localhost`, so the key never leaves the machine. If the bot is on another
machine, this feature cannot be used as set up here.

If the bot is offline, the Servers page shows "The Noxy bot is not reachable right now." The
rest of the dashboard keeps working.

## Privacy rules (member side)

- A member's profile and activity come only from their own Discord login. The API
  never takes a user ID from the request.
- Moderator IDs are never shown to members. Members see their own warnings and
  infractions, without who issued them.

## Pages

Member dashboard:

- **Overview**: what Noxy does, with buttons to add the bot and join the support server, and links to Servers, Analysis and Terms.
- **Terms & Privacy**: the Terms of Service and Privacy Policy. Visible to everyone from the footer.
- **Analysis**: messages, warnings and infractions for each server.
- **Servers**: the servers where you have Manage Server and Noxy is installed. Open one to change its welcome and goodbye messages, join roles, log channel, AutoMod and disabled commands. Changes save to the bot and apply right away.

Staff dashboard:

- **Overview**: totals, top commands, moderation totals, most moderated and most
  active servers, and feature adoption across servers.
- **Servers**: every server with saved settings, searchable by ID and sortable.
  Each one opens a detail page with enabled features, top chatters, recent
  warnings and infractions, tickets, giveaways, anti-nuke events, AutoMod and
  starboard settings, and custom commands.
- **Economy**: wealth in circulation, the top 25 by wealth, level spread and the
  most held items.
- **System**: database size, last write time, and connection health.

## API

All endpoints are `GET` unless noted, and return JSON.

| Endpoint | Auth | Returns |
|---|---|---|
| `/api/health` | none | Status, auth mode, whether member login is configured |
| `/auth/login` | none | Redirects to Discord |
| `/auth/callback` | none | Finishes login, then redirects to `/` |
| `POST /auth/logout` | session | Ends the session |
| `/api/member/me` | member session | The signed-in member's profile |
| `/api/member/leaderboard?metric=coins\|level\|wins` | member session | Masked top 10 and your rank |
| `/api/summary`, `/api/guilds`, `/api/guilds/:id`, `/api/economy` | staff token | Staff views (404 if unknown) |

## Notes and limits

- **Server names are not shown.** The database stores only server IDs.
- **"Tracking since" is not a restart time.** The bot writes `bot.startedAt` once,
  when the database is first created, so the dashboard labels it that way.
- **Live bot status is not shown.** The dashboard reads the file the bot saves.
  The System page shows how old the last write is.
- **If the file is mid-write or invalid,** the dashboard keeps the last good copy
  and reports the problem in the banner and `/api/health`.
- **Server settings were tested against a mock bot API**, not the live bot. Test one change on
  a real server before you rely on it.
- **Discord login was tested against a mock Discord server**, not the live
  service. Check it once with your real client secret before going public.
- Tested on Linux with GCC 13. The code should build on macOS and Windows with
  Clang or MSVC, but that has not been tested.

## Layout

```
src/stats.{hpp,cpp}           aggregation: database JSON -> dashboard views
src/database_store.{hpp,cpp}  cached, reload-on-change reader for the database file
src/discord_auth.{hpp,cpp}    Discord OAuth2 login and in-memory sessions
src/main.cpp                  HTTP server, routes, token check, arguments
web/member/                   member dashboard (index.html, app.js, styles.css)
web/admin/                    staff dashboard (index.html, app.js, styles.css)
tests/                        unit tests and a fixture with hand-checked values
demo/levidatabase.json        sample data to try the dashboard without the bot
third_party/                  vendored cpp-httplib 0.18.3 and nlohmann/json 3.11.3
```
