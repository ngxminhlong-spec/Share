/* Noxy Dashboard: front end.
   Plain JavaScript, no build step and no external requests. Everything that comes
   from the database is escaped before it is placed in the page. */
(() => {
  'use strict';

  const REFRESH_MS = 15000;
  const TOKEN_KEY = 'noxy.dashboard.token';          // sessionStorage: cleared when the tab closes
  const AUTO_KEY = 'noxy.dashboard.autoRefresh';     // localStorage: a viewer preference only

  // ---------- helpers ----------

  const $ = (sel, root = document) => root.querySelector(sel);
  const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c]));

  const nf = new Intl.NumberFormat('en-US');
  const cf = new Intl.NumberFormat('en-US', { notation: 'compact', maximumFractionDigits: 1 });
  const num = (n) => {
    const v = Number(n) || 0;
    return Math.abs(v) >= 100000 ? cf.format(v) : nf.format(Math.round(v));
  };
  const pct = (n) => `${(Math.round((Number(n) || 0) * 10) / 10).toFixed(1).replace(/\.0$/, '')}%`;
  const barPct = (value, max) => (max > 0 ? Math.max(value > 0 ? 2 : 0, Math.min(100, (value / max) * 100)) : 0);
  const plural = (n, word, many = `${word}s`) => (Number(n) === 1 ? word : many);

  function dur(ms) {
    if (!ms || ms <= 0) return '—';
    const s = Math.floor(ms / 1000);
    const d = Math.floor(s / 86400);
    const h = Math.floor((s % 86400) / 3600);
    const m = Math.floor((s % 3600) / 60);
    if (d) return `${d}d ${h}h`;
    if (h) return `${h}h ${m}m`;
    if (m) return `${m}m`;
    return `${s}s`;
  }

  function ago(ms) {
    if (!ms) return 'never';
    const diff = Date.now() - ms;
    if (diff < 5000) return 'just now';
    if (diff < 60000) return `${Math.floor(diff / 1000)}s ago`;
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
    return `${Math.floor(diff / 86400000)}d ago`;
  }

  function when(ms) {
    if (!ms) return '—';
    return new Date(ms).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });
  }

  function bytes(n) {
    const v = Number(n) || 0;
    if (v < 1024) return `${v} B`;
    if (v < 1024 * 1024) return `${(v / 1024).toFixed(1)} KB`;
    return `${(v / 1024 / 1024).toFixed(2)} MB`;
  }

  // Stable hue per ID, so each member keeps the same avatar colour.
  function avatar(id) {
    const text = String(id);
    let h = 7;
    for (let i = 0; i < text.length; i += 1) h = (h * 31 + text.charCodeAt(i)) >>> 0;
    return `<span class="avatar" style="--h:${h % 360}" aria-hidden="true">${esc(text.slice(-2))}</span>`;
  }

  // Lucide icons, loaded from icons.js. Each name maps to that icon's inner SVG markup.
  const ICONS = window.NOXY_ICONS || {};
  const icon = (name, size = 18) => `<svg class="ico-svg" viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${ICONS[name] || ''}</svg>`;

  const tile = (name, tint, label, value, note) => {
    const isNumber = typeof value === 'number';
    const shown = isNumber ? `<div class="kpi-value" data-count="${value}">${num(value)}</div>`
      : `<div class="kpi-value">${esc(value)}</div>`;
    return `
    <div class="card kpi" style="--tint:${tint}">
      <div class="kpi-top">
        <span class="kpi-label">${esc(label)}</span>
        <span class="tile-icon">${icon(name)}</span>
      </div>
      ${shown}
      ${note ? `<div class="kpi-note">${esc(note)}</div>` : ''}
    </div>`;
  };

  const barRow = (label, valueText, percent, tone = '', labelHtml = null) => `
    <div class="bar-row">
      <div class="bar-meta">
        <span class="name">${labelHtml ?? esc(label)}</span>
        <span class="value">${valueText}</span>
      </div>
      <div class="track-bar"><div class="fill ${tone}" style="--w:${percent.toFixed(2)}%"></div></div>
    </div>`;

  const empty = (text) => `<div class="empty">${esc(text)}</div>`;

  const badge = (on, label, tone = '') => `<span class="badge ${on ? 'on' : 'off'} ${tone}">${esc(label)}</span>`;

  const rankClass = (i) => (i === 0 ? 'gold' : i === 1 ? 'silver' : i === 2 ? 'bronze' : '');

  // ---------- state ----------

  const state = {
    health: null,
    summary: null,
    guilds: null,
    economy: null,
    detail: null,
    detailId: null,
    notFound: false,
    search: '',
    sort: 'activity',
    mounted: null,          // which view shell is on screen
    sigs: {},               // last rendered signature per view, to skip unchanged renders
    lastOk: 0,
    status: 'connecting',
    statusText: 'Connecting…',
    banner: '',
    bannerTone: 'warn',
    busy: false,
    authPending: false,
  };

  // ---------- routing ----------

  const META = {
    overview: { title: 'Overview', sub: 'Everything Noxy is doing, at a glance.', crumb: 'Noxy' },
    servers: { title: 'Servers', sub: 'Every server with saved settings, ranked by activity.', crumb: 'Noxy' },
    economy: { title: 'Economy', sub: 'Balances, levels and the most popular items.', crumb: 'Noxy' },
    system: { title: 'System', sub: 'Database status and how this dashboard reads it.', crumb: 'Noxy' },
  };

  function currentRoute() {
    const parts = location.hash.replace(/^#\/?/, '').split('/').filter(Boolean);
    if (parts[0] === 'servers' && /^\d{1,25}$/.test(parts[1] || '')) return { name: 'server', id: parts[1] };
    if (['servers', 'economy', 'system'].includes(parts[0])) return { name: parts[0] };
    return { name: 'overview' };
  }

  function setChrome(route) {
    const meta = route.name === 'server'
      ? { title: `Server ${route.id}`, sub: 'Settings, activity and moderation for one server.', crumb: `<a href="#/servers">Servers</a> / ${esc(route.id)}` }
      : META[route.name];
    $('#title').textContent = meta.title;
    $('#subtitle').textContent = meta.sub;
    $('#crumb').innerHTML = meta.crumb.includes('<a') ? meta.crumb : esc(meta.crumb);
    document.title = `${meta.title} · Noxy Dashboard`;
    document.querySelectorAll('[data-route]').forEach((a) => {
      if (a.dataset.route === route.name || (route.name === 'server' && a.dataset.route === 'servers')) {
        a.setAttribute('aria-current', 'page');
      } else {
        a.removeAttribute('aria-current');
      }
    });
  }

  // ---------- data ----------

  function readToken() {
    try { return sessionStorage.getItem(TOKEN_KEY) || ''; } catch { return ''; }
  }
  function writeToken(value) {
    try {
      if (value) sessionStorage.setItem(TOKEN_KEY, value);
      else sessionStorage.removeItem(TOKEN_KEY);
    } catch { /* storage unavailable: the token is kept only for this page load */ }
  }

  async function api(path) {
    const headers = {};
    const token = readToken();
    if (token) headers['X-Dashboard-Token'] = token;
    let res;
    try {
      res = await fetch(path, { headers, cache: 'no-store' });
    } catch {
      throw Object.assign(new Error('Cannot reach the dashboard server.'), { kind: 'network' });
    }
    if (res.status === 401) throw Object.assign(new Error('Token rejected.'), { kind: 'auth' });
    const body = await res.json().catch(() => ({}));
    if (!res.ok) throw Object.assign(new Error(body.error || `Request failed (${res.status}).`), { kind: 'http', status: res.status });
    return body;
  }

  async function fetchHealth() {
    try {
      const res = await fetch('/api/health', { cache: 'no-store' });
      return await res.json();
    } catch {
      return null;
    }
  }

  function setStatus(status, text) {
    state.status = status;
    state.statusText = text;
    const el = $('#status');
    el.dataset.state = status;
    $('#statusText').textContent = text;
  }

  function setBanner(message, tone = 'warn') {
    const el = $('#banner');
    state.banner = message;
    state.bannerTone = tone;
    el.hidden = !message;
    el.dataset.tone = tone;
    el.textContent = message || '';
  }

  function showAuth(message = '') {
    state.authPending = true;
    $('#auth').hidden = false;
    $('#authError').hidden = !message;
    if (message) $('#authError').textContent = message;
    setTimeout(() => $('#authToken')?.focus(), 30);
  }

  function hideAuth() {
    state.authPending = false;
    $('#auth').hidden = true;
  }

  async function refresh({ manual = false } = {}) {
    if (state.busy || state.authPending) return;
    state.busy = true;
    const btn = $('#refreshBtn');
    if (manual) btn.classList.add('spin');

    const route = currentRoute();
    try {
      state.health = await fetchHealth();
      if (state.health?.authRequired && !readToken()) {
        showAuth();
        return;
      }

      if (route.name === 'overview' || route.name === 'system') {
        state.summary = await api('/api/summary');
      } else if (route.name === 'servers') {
        state.guilds = await api('/api/guilds');
      } else if (route.name === 'economy') {
        state.economy = await api('/api/economy');
      } else if (route.name === 'server') {
        if (state.detailId !== route.id) {
          state.detail = null;
          state.detailId = route.id;
        }
        try {
          state.detail = await api(`/api/guilds/${route.id}`);
          state.notFound = false;
        } catch (err) {
          if (err.status === 404) {
            state.detail = null;
            state.notFound = true;
          } else {
            throw err;
          }
        }
      }

      state.lastOk = Date.now();
      if (state.health && state.health.ok === false && state.health.error) {
        setBanner(state.health.error, 'warn');
        setStatus('warn', 'Showing last good copy');
      } else {
        setBanner('');
        setStatus('ok', 'Live');
      }
      render(route);
    } catch (err) {
      if (err.kind === 'auth') {
        const hadToken = Boolean(readToken());
        writeToken('');
        showAuth(hadToken ? 'That token was not accepted.' : '');
        return;
      }
      setStatus('error', err.kind === 'network' ? 'Offline' : 'Error');
      setBanner(err.message, 'error');
    } finally {
      state.busy = false;
      btn.classList.remove('spin');
    }
  }

  // ---------- rendering ----------

  function render(route, { force = false } = {}) {
    setChrome(route);
    const view = $('#view');
    const key = route.name === 'server' ? `server:${route.id}` : route.name;
    // Ignore detail data left over from a different server while the new one loads.
    const staleDetail = route.name === 'server' && state.detail && String(state.detail.summary.id) !== route.id;
    const data = {
      overview: state.summary, system: state.summary, servers: state.guilds,
      economy: state.economy, server: state.notFound ? 'missing' : (staleDetail ? null : state.detail),
    }[route.name];
    const sig = JSON.stringify([data, state.health?.ok, state.health?.error, state.status]);
    const fresh = state.mounted !== key;

    if (!force && !fresh && state.sigs[key] === sig) return;
    state.sigs[key] = sig;
    state.mounted = key;

    if (route.name === 'servers') {
      if (fresh) view.innerHTML = viewServersShell();
      updateServerGrid();
      return;
    }

    let html;
    if (route.name === 'overview') html = viewOverview(state.summary);
    else if (route.name === 'economy') html = viewEconomy(state.economy);
    else if (route.name === 'system') html = viewSystem(state.summary, state.health);
    else if (route.name === 'server') html = viewServer(route.id, staleDetail ? null : state.detail, state.notFound);
    else html = empty('Nothing to show.');

    // Entrance animations play only when a page is first shown. Routine refreshes
    // update the numbers in place without replaying them.
    view.classList.toggle('no-motion', !fresh);
    view.innerHTML = html;
    if (fresh) {
      view.querySelectorAll('.card, .hero').forEach((el, i) => { el.style.animationDelay = `${Math.min(i, 8) * 45}ms`; });
      countUp(view);
    }
  }

  function countUp(root) {
    const reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    root.querySelectorAll('[data-count]').forEach((el) => {
      const target = Number(el.dataset.count) || 0;
      if (reduce || target === 0) { el.textContent = num(target); return; }
      const start = performance.now();
      const dur2 = 900;
      const step = (now) => {
        const t = Math.min(1, (now - start) / dur2);
        const eased = 1 - Math.pow(1 - t, 3);
        el.textContent = num(Math.round(target * eased));
        if (t < 1) requestAnimationFrame(step);
      };
      requestAnimationFrame(step);
    });
  }

  // ----- overview -----

  function viewOverview(s) {
    if (!s) return empty('Waiting for data…');
    const t = s.totals;
    const b = s.bot;
    const d = s.database;
    const maxCmd = s.topCommands[0]?.count || 0;
    const commandsHtml = s.topCommands.length
      ? `<div class="bars">${s.topCommands.map((c) => barRow(c.name, num(c.count), barPct(c.count, maxCmd), '', `<span class="faint">n?</span>${esc(c.name)}`)).join('')}</div>`
      : empty('No commands have been recorded yet.');

    const featureRows = [...s.features].sort((a, b2) => b2.guilds - a.guilds || a.label.localeCompare(b2.label));
    const featuresHtml = featureRows.map((f) => barRow(f.label, `${num(f.guilds)} of ${num(t.guilds)}`, Math.max(0, f.percent), f.guilds ? 'ok' : '')).join('');

    const topGuilds = s.topGuilds;
    const topGuildsHtml = topGuilds.length
      ? `<div class="table-wrap"><table>
          <thead><tr><th>#</th><th>Server</th><th class="right">Messages</th><th class="right">Commands</th><th class="right">Open tickets</th></tr></thead>
          <tbody>${topGuilds.map((g, i) => `
            <tr>
              <td><span class="rank ${rankClass(i)}">${i + 1}</span></td>
              <td><a class="who" href="#/servers/${esc(g.id)}"><span class="guild-icon" style="width:34px;height:34px;border-radius:11px;font-size:12px" aria-hidden="true">${esc(String(g.id).slice(0, 2))}</span><span style="min-width:0"><span class="id" style="display:block">${esc(g.id)}</span><span class="sub2">${g.features} of ${g.featureTotal} features on</span></span></a></td>
              <td class="right">${num(g.messages)}</td>
              <td class="right">${num(g.commands)}</td>
              <td class="right">${num(g.openTickets)}</td>
            </tr>`).join('')}
          </tbody></table></div>`
      : empty('No servers have saved settings yet.');

    return `
      <section class="card hero">
        <div>
          <span class="eyebrow">Live from your database</span>
          <h2>Noxy is set up in <b>${num(t.guilds)}</b> ${plural(t.guilds, 'server')}</h2>
          <p>${num(t.users)} ${plural(t.users, 'member')} ${plural(t.users, 'has', 'have')} an economy profile, and ${num(t.messages)} messages have been counted across all servers.</p>
        </div>
        <div class="hero-chips">
          <div class="chip-stat"><span>Tracking since</span><b>${esc(b.trackingSince ? new Date(b.trackingSince).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) : '—')}</b></div>
          <div class="chip-stat"><span>Unique commands</span><b>${num(b.uniqueCommands)}</b></div>
          <div class="chip-stat"><span>Database</span><b>${esc(bytes(d.bytes))}</b></div>
        </div>
      </section>

      <section class="grid kpis">
        ${tile('server', '#60a5fa', 'Servers', t.guilds, 'With saved settings')}
        ${tile('users', '#7c8cff', 'Members', t.users, 'With economy profiles')}
        ${tile('message', '#5ee6a8', 'Messages counted', t.messages, 'All-time, every server')}
        ${tile('terminal', '#ffb020', 'Commands run', t.commands, 'All-time, global counter')}
      </section>

      <section class="grid split-7-5">
        <div class="card">
          <div class="card-head"><h2>Top commands</h2><span class="hint">All-time usage</span></div>
          ${commandsHtml}
        </div>
        <div class="card">
          <div class="card-head"><h2>Moderation</h2><span class="hint">Totals across servers</span></div>
          <div class="grid" style="grid-template-columns:repeat(2,minmax(0,1fr));gap:12px">
            ${miniTile('Warnings', t.warnings, 'warn')}
            ${miniTile('Infractions', t.infractions, 'warn')}
            ${miniTile('Open tickets', t.openTickets, '')}
            ${miniTile('Active giveaways', t.activeGiveaways, '')}
          </div>
          <div class="card-head" style="margin:22px 0 14px"><h3 style="font-size:14px">Most moderated servers</h3><span class="hint">Warnings + infractions</span></div>
          ${s.topModerated.length
            ? `<div class="bars">${s.topModerated.map((m) => {
                const total = m.warnings + m.infractions;
                const top = s.topModerated[0].warnings + s.topModerated[0].infractions;
                return barRow(`Server ${m.id}`, `${num(m.warnings)} warn · ${num(m.infractions)} infr`, barPct(total, top), 'warn');
              }).join('')}</div>`
            : '<p class="faint small">No warnings or infractions recorded.</p>'}
        </div>
      </section>

      <section class="grid split-7-5">
        <div class="card">
          <div class="card-head"><h2>Most active servers</h2><a class="hint" href="#/servers">View all →</a></div>
          ${topGuildsHtml}
        </div>
        <div class="card">
          <div class="card-head"><h2>Feature adoption</h2><span class="hint">${num(t.guilds)} ${plural(t.guilds, 'server')}</span></div>
          <div class="bars" style="max-height:440px;overflow:auto;padding-right:6px">${featuresHtml}</div>
        </div>
      </section>`;
  }

  function miniTile(label, value, tone) {
    return `<div class="mini ${tone}"><span>${esc(label)}</span><b class="num">${num(value)}</b></div>`;
  }

  // ----- servers -----

  function viewServersShell() {
    return `
      <div class="toolbar">
        <label class="search">
          ${icon('search', 16)}
          <span class="sr-only">Search servers by ID</span>
          <input class="input" id="serverSearch" type="search" placeholder="Search by server ID" value="${esc(state.search)}" autocomplete="off">
        </label>
        <select class="input select" id="serverSort" aria-label="Sort servers">
          ${[['activity', 'Most active'], ['commands', 'Most commands'], ['features', 'Most features'], ['tickets', 'Most open tickets'], ['warnings', 'Most warnings']]
            .map(([v, l]) => `<option value="${v}" ${state.sort === v ? 'selected' : ''}>${l}</option>`).join('')}
        </select>
      </div>
      <div id="guildGrid" class="grid cards-3"></div>`;
  }

  function sortGuilds(list) {
    const keyFor = {
      activity: (g) => g.messages,
      commands: (g) => g.commands,
      features: (g) => g.features,
      tickets: (g) => g.openTickets,
      warnings: (g) => g.warnings,
    }[state.sort] || ((g) => g.messages);
    return [...list].sort((a, b) => keyFor(b) - keyFor(a) || (a.id < b.id ? -1 : 1));
  }

  function updateServerGrid() {
    const grid = $('#guildGrid');
    if (!grid) return;
    const list = state.guilds;
    if (!list) { grid.innerHTML = empty('Loading servers…'); return; }
    const q = state.search.trim();
    const filtered = sortGuilds(list).filter((g) => !q || String(g.id).includes(q));
    if (!list.length) {
      grid.innerHTML = `<div style="grid-column:1/-1">${empty('No servers have saved settings yet. They appear here once Noxy stores something for them.')}</div>`;
      return;
    }
    if (!filtered.length) {
      grid.innerHTML = `<div style="grid-column:1/-1">${empty('No server matches that ID.')}</div>`;
      return;
    }
    const maxMsg = Math.max(...list.map((g) => g.messages), 0);
    grid.innerHTML = filtered.map((g) => serverCard(g, maxMsg)).join('');
  }

  function serverCard(g, maxMsg) {
    const frac = g.featureTotal ? g.features / g.featureTotal : 0;
    const C = 2 * Math.PI * 20;
    return `
      <a class="card guild" href="#/servers/${esc(g.id)}" aria-label="Open server ${esc(g.id)}">
        <div class="guild-head">
          <div class="guild-icon" aria-hidden="true">${esc(String(g.id).slice(0, 2))}</div>
          <div style="min-width:0">
            <div class="guild-title">Server</div>
            <div class="guild-id">${esc(g.id)}</div>
          </div>
          <div class="ring" title="${g.features} of ${g.featureTotal} features enabled" aria-hidden="true">
            <svg viewBox="0 0 48 48"><circle class="bg" cx="24" cy="24" r="20" fill="none" stroke-width="4"/>
              <circle class="fg" cx="24" cy="24" r="20" fill="none" stroke-width="4" stroke-linecap="round" stroke-dasharray="${(C * frac).toFixed(2)} ${C.toFixed(2)}"/></svg>
            <span>${g.features}</span>
          </div>
        </div>
        <div class="guild-stats">
          <div class="mini"><span>Messages</span><b>${num(g.messages)}</b></div>
          <div class="mini"><span>Commands</span><b>${num(g.commands)}</b></div>
          <div class="mini ${g.warnings ? 'warn' : ''}"><span>Warnings</span><b>${num(g.warnings)}</b></div>
          <div class="mini"><span>Open tickets</span><b>${num(g.openTickets)}</b></div>
        </div>
        <div class="track-bar" style="height:6px" aria-hidden="true"><div class="fill" style="--w:${barPct(g.messages, maxMsg).toFixed(1)}%"></div></div>
        <div class="badges">
          ${badge(g.automod, 'AutoMod')}
          ${badge(g.antiNuke, 'Anti-nuke')}
          ${badge(g.welcome, 'Welcome')}
          ${badge(g.logChannel, 'Logs')}
        </div>
      </a>`;
  }

  // ----- server detail -----

  function viewServer(id, d, notFound) {
    if (notFound) {
      return `<div class="card">${empty(`Server ${id} is not in the database. It may not have saved settings yet.`)}
        <p style="margin-top:16px"><a class="btn" href="#/servers">${icon('back', 16)}<span>Back to servers</span></a></p></div>`;
    }
    if (!d) return empty('Loading server…');
    const s = d.summary;

    const groups = {};
    d.features.forEach((f) => { (groups[f.category] ||= []).push(f); });
    const featureHtml = Object.entries(groups).map(([cat, items]) => `
      <div class="feature-group">
        <h3>${esc(cat)}</h3>
        ${items.map((f) => `<div class="feature ${f.enabled ? 'on' : ''}"><span class="dot"></span>${esc(f.label)}</div>`).join('')}
      </div>`).join('');

    const maxChat = d.topChatters[0]?.messages || 0;
    const chattersHtml = d.topChatters.length
      ? `<div class="bars">${d.topChatters.map((c) => `
          <div class="bar-row">
            <div class="bar-meta"><span class="who" style="gap:10px"><span class="avatar" style="--h:${hashHue(c.userId)};width:26px;height:26px;font-size:10px">${esc(String(c.userId).slice(-2))}</span><span class="id">${esc(c.userId)}</span></span><span class="value">${num(c.messages)} msgs</span></div>
            <div class="track-bar"><div class="fill" style="--w:${barPct(c.messages, maxChat).toFixed(2)}%"></div></div>
          </div>`).join('')}</div>`
      : empty('No messages counted yet.');

    const am = d.automod;
    const an = d.antiNuke;
    const warnings = d.warnings.length
      ? `<div class="list">${d.warnings.map((w) => listItem('alert', w.reason || 'No reason given', `Member ${w.userId} · by ${w.moderatorId || 'unknown'}`, w.at)).join('')}</div>`
      : empty('No warnings recorded.');
    const infractions = d.infractions.length
      ? `<div class="list">${d.infractions.map((w) => listItem('shield', `${w.type || 'Infraction'}${w.reason ? ` — ${w.reason}` : ''}`, `Member ${w.userId} · by ${w.moderatorId || 'unknown'}`, w.at)).join('')}</div>`
      : empty('No infractions recorded.');

    const tickets = d.tickets.length
      ? `<div class="table-wrap"><table>
          <thead><tr><th>Channel</th><th>Opened by</th><th>Status</th></tr></thead>
          <tbody>${d.tickets.map((t) => `<tr>
            <td class="mono">${esc(t.channelId)}</td>
            <td class="mono">${esc(t.ownerId || '—')}</td>
            <td>${badge(true, t.claimed ? 'Claimed' : 'Open')}</td></tr>`).join('')}
          </tbody></table></div>`
      : empty('No tickets yet.');

    const giveaways = d.giveaways.length
      ? `<div class="list">${d.giveaways.map((g) => `
          <div class="item">
            <span class="ico" style="color:${g.finished ? 'var(--text-3)' : 'var(--ok)'};background:${g.finished ? 'var(--surface)' : 'rgba(94,230,168,.1)'};border-color:${g.finished ? 'var(--line)' : 'rgba(94,230,168,.25)'}">${icon('gift', 16)}</span>
            <div style="min-width:0"><div class="title">${esc(g.prize || 'Giveaway')}</div><div class="meta">Message ${esc(g.messageId)}</div></div>
            <div class="time">${g.finished ? 'Ended' : 'Ends'} ${esc(g.endsAt ? when(g.endsAt) : '—')}</div>
          </div>`).join('')}</div>`
      : empty('No giveaways yet.');

    const events = an.recent.length
      ? `<div class="list">${an.recent.map((e) => `
          <div class="item event">
            <span class="ico">${icon('bolt', 16)}</span>
            <div style="min-width:0">
              <div class="title">Anti-nuke event</div>
              <div class="kvs">${e.fields.map((f) => `<span>${esc(f.key)} <b>${esc(prettyField(f.key, f.value))}</b></span>`).join('') || '<span>No details</span>'}</div>
            </div>
            <div class="time"></div>
          </div>`).join('')}</div>`
      : empty('No anti-nuke events recorded.');

    return `
      <section class="card hero" style="grid-template-columns:minmax(0,1fr)">
        <div>
          <span class="eyebrow">Server ${esc(d.summary.id)}</span>
          <h2>Server <b>${esc(d.summary.id)}</b></h2>
          <div class="badges" style="margin-top:16px">
            ${badge(am.enabled, 'AutoMod')}
            ${badge(an.enabled, 'Anti-nuke')}
            ${badge(s.welcome, 'Welcome')}
            ${badge(s.logChannel, 'Log channel')}
            ${badge(d.starboard.enabled, 'Starboard')}
          </div>
          <p style="margin-top:14px">${s.features} of ${s.featureTotal} features enabled.</p>
        </div>
      </section>

      <section class="grid kpis">
        ${tile('message', '#5ee6a8', 'Messages', s.messages, 'All-time, this server')}
        ${tile('terminal', '#60a5fa', 'Commands', s.commands, 'Run in this server')}
        ${miniWarnTile('Warnings', s.warnings)}
        ${tile('ticket', '#7c8cff', 'Open tickets', s.openTickets, `${num(s.totalTickets)} total`)}
      </section>

      <section class="card">
        <div class="card-head"><h2>Features</h2><span class="hint">${s.features} of ${s.featureTotal} on</span></div>
        <div class="feature-groups">${featureHtml}</div>
      </section>

      <section class="grid split-7-5">
        <div class="card">
          <div class="card-head"><h2>Top chatters</h2><span class="hint">All-time message count</span></div>
          ${chattersHtml}
        </div>
        <div class="card">
          <div class="card-head"><h2>Configuration</h2><span class="hint">Read-only</span></div>
          <h3 class="small faint" style="text-transform:uppercase;letter-spacing:.08em;margin-bottom:10px">AutoMod</h3>
          <dl class="kv" style="margin:0 0 20px">
            <dt>Punishment</dt><dd>${esc(am.punishment || '—')}</dd>
            <dt>Mention limit</dt><dd>${num(am.mentionLimit)}</dd>
            <dt>Spam</dt><dd>${num(am.spamLimit)} msgs / ${num(am.spamWindowSeconds)}s</dd>
            <dt>Blocked words</dt><dd>${num(am.badwords)}</dd>
            <dt>Timeout</dt><dd>${num(am.timeoutSeconds)}s</dd>
          </dl>
          <h3 class="small faint" style="text-transform:uppercase;letter-spacing:.08em;margin-bottom:10px">Anti-nuke</h3>
          <dl class="kv" style="margin:0 0 20px">
            <dt>Action</dt><dd>${esc(an.action || '—')}</dd>
            <dt>Bot action</dt><dd>${esc(an.botAction || '—')}</dd>
            <dt>Window</dt><dd>${num(an.windowSeconds)}s</dd>
            <dt>Logged events</dt><dd>${num(an.events)}</dd>
          </dl>
          <h3 class="small faint" style="text-transform:uppercase;letter-spacing:.08em;margin-bottom:10px">Starboard</h3>
          <dl class="kv" style="margin:0 0 20px">
            <dt>Threshold</dt><dd>${num(d.starboard.threshold)} ⭐</dd>
            <dt>Starred posts</dt><dd>${num(d.starboard.starred)}</dd>
          </dl>
          <h3 class="small faint" style="text-transform:uppercase;letter-spacing:.08em;margin-bottom:10px">Custom commands</h3>
          ${d.customCommands.length ? `<div class="chips">${d.customCommands.map((c) => `<span>n?${esc(c)}</span>`).join('')}</div>` : '<p class="faint small">None configured.</p>'}
        </div>
      </section>

      <section class="grid split-1-1">
        <div class="card"><div class="card-head"><h2>Recent warnings</h2><span class="hint">Newest first</span></div>${warnings}</div>
        <div class="card"><div class="card-head"><h2>Recent infractions</h2><span class="hint">Newest first</span></div>${infractions}</div>
      </section>

      <section class="grid split-1-1">
        <div class="card"><div class="card-head"><h2>Tickets</h2><span class="hint">Latest 10</span></div>${tickets}</div>
        <div class="card"><div class="card-head"><h2>Giveaways</h2><span class="hint">Latest 10</span></div>${giveaways}</div>
      </section>

      <section class="card">
        <div class="card-head"><h2>Anti-nuke events</h2><span class="hint">Latest 8</span></div>
        ${events}
      </section>`;
  }

  // Timestamps arrive as Unix milliseconds; show them as dates. Other values pass through.
  function prettyField(key, value) {
    if (/(^at$|At$)/.test(key) && /^\d{10,}$/.test(String(value))) return when(Number(value));
    if (/^\d{17,}$/.test(String(value))) return String(value);  // Discord IDs stay exact
    return value;
  }

  function miniWarnTile(label, value) {
    return tile('shield', '#ffb020', label, value, 'Issued in this server');
  }

  function listItem(iconName, title, meta, at) {
    return `
      <div class="item">
        <span class="ico">${icon(iconName, 16)}</span>
        <div style="min-width:0">
          <div class="title">${esc(title)}</div>
          <div class="meta">${esc(meta)}</div>
        </div>
        <div class="time">${esc(ago(at))}</div>
      </div>`;
  }

  function hashHue(id) {
    const text = String(id);
    let h = 7;
    for (let i = 0; i < text.length; i += 1) h = (h * 31 + text.charCodeAt(i)) >>> 0;
    return h % 360;
  }

  // ----- economy -----

  function viewEconomy(e) {
    if (!e) return empty('Loading economy…');
    const t = e.totals;
    const top = e.leaderboard[0]?.wealth || 0;
    const rows = e.leaderboard.length
      ? `<div class="table-wrap"><table>
          <thead><tr><th>#</th><th>Member</th><th class="right">Level</th><th style="min-width:190px">Wealth</th></tr></thead>
          <tbody>${e.leaderboard.map((u, i) => `<tr>
            <td><span class="rank ${rankClass(i)}">${i + 1}</span></td>
            <td><div class="who">${avatar(u.userId)}<div style="min-width:0"><div class="id">${esc(u.userId)}</div><div class="sub2">${num(u.coins)} coins · ${num(u.bank)} banked</div></div></div></td>
            <td class="right">${num(u.level)}</td>
            <td><div class="track-bar" style="height:6px"><div class="fill" style="--w:${barPct(u.wealth, top).toFixed(1)}%"></div></div><div class="faint small" style="margin-top:4px;font-variant-numeric:tabular-nums">${num(u.wealth)}</div></td>
          </tr>`).join('')}</tbody></table></div>`
      : empty('No economy profiles yet.');

    const maxLevel = Math.max(...e.levels.map((l) => l.count), 0);
    const levels = `<div class="levels" role="img" aria-label="Members by level">${e.levels.map((l) => `
      <div class="level-col">
        <div class="col" style="--h:${barPct(l.count, maxLevel).toFixed(1)}%"><b>${num(l.count)}</b></div>
        <span class="lbl">Lv ${esc(l.label)}</span>
      </div>`).join('')}</div>`;

    const inventory = e.inventory.length
      ? `<div class="inv-grid">${e.inventory.map((item) => `
          <div class="inv">
            <div class="name">${esc(item.name)}</div>
            <div class="qty">${num(item.total)}</div>
            <div class="holders">${num(item.holders)} ${plural(item.holders, 'holder')}</div>
          </div>`).join('')}</div>`
      : empty('Nobody has items yet.');

    return `
      <section class="grid kpis">
        ${tile('coin', '#ffb020', 'Wealth in circulation', t.wealth, `${num(t.coins)} in wallets · ${num(t.bank)} banked`)}
        ${tile('trophy', '#60a5fa', 'Average level', (Math.round(t.averageLevel * 10) / 10).toFixed(1), `${num(t.users)} ${plural(t.users, 'member')}`)}
        ${tile('bolt', '#5ee6a8', 'Win rate', pct(t.winRate), `${num(t.wins)} wins from ${num(t.games)} games`)}
        ${tile('sparkle', '#7c8cff', 'Total XP', t.xp, 'Earned across all members')}
      </section>

      <section class="grid split-7-5">
        <div class="card">
          <div class="card-head"><h2>Wealth leaderboard</h2><span class="hint">Top 25 by coins + bank</span></div>
          ${rows}
        </div>
        <div class="card">
          <div class="card-head"><h2>Level spread</h2><span class="hint">Members per level band</span></div>
          ${levels}
        </div>
      </section>

      <section class="card">
        <div class="card-head"><h2>Popular items</h2><span class="hint">Total held across all members</span></div>
        ${inventory}
      </section>`;
  }

  // ----- system -----

  function viewSystem(s, health) {
    if (!s) return empty('Loading…');
    const d = s.database;
    const stale = d.ageMs > 1000 * 60 * 60 * 24 * 7;
    const sections = `
      <section class="grid split-1-1">
        <div class="card">
          <div class="card-head"><h2>Database</h2>${badge(!stale, stale ? 'Not updated recently' : 'Up to date', stale ? '' : '')}</div>
          <dl class="kv">
            <dt>File</dt><dd class="mono">${esc(health?.database || 'levidatabase.json')}</dd>
            <dt>Size</dt><dd>${esc(bytes(d.bytes))}</dd>
            <dt>Last written</dt><dd>${esc(when(d.modifiedAt))}</dd>
            <dt>Age</dt><dd>${esc(ago(d.modifiedAt))}</dd>
            <dt>Servers</dt><dd>${num(d.guildCount)}</dd>
            <dt>Members</dt><dd>${num(d.userCount)}</dd>
            <dt>Tracking since</dt><dd>${esc(s.bot.trackingSince ? when(s.bot.trackingSince) : '—')}</dd>
          </dl>
          <p class="faint small" style="margin-top:18px">The bot writes this file whenever its data changes. The dashboard reloads it automatically when it changes, and it never writes to it.</p>
        </div>
        <div class="card">
          <div class="card-head"><h2>Connection</h2>${badge(health?.ok !== false, health?.ok === false ? 'Degraded' : 'Healthy')}</div>
          <dl class="kv">
            <dt>Access</dt><dd>${health?.authRequired ? 'Token required' : 'Open (local use)'}</dd>
            <dt>Server time</dt><dd>${esc(when(health?.serverTime))}</dd>
            <dt>Dashboard refresh</dt><dd>Every ${REFRESH_MS / 1000}s</dd>
          </dl>
          ${health?.error ? `<p class="err small" style="margin-top:16px">${esc(health.error)}</p>` : ''}
        </div>
      </section>

      <section class="card">
        <div class="card-head"><h2>API</h2><span class="hint">JSON, read-only</span></div>
        <div class="chips">
          <span>GET /api/health</span><span>GET /api/summary</span><span>GET /api/guilds</span>
          <span>GET /api/guilds/:id</span><span>GET /api/economy</span>
        </div>
      </section>`;
    return sections;
  }

  // ---------- events & boot ----------

  function tick() {
    if (state.lastOk) {
      const text = state.status === 'ok' ? `Live · updated ${ago(state.lastOk)}` : state.statusText;
      $('#statusText').textContent = text;
    }
  }

  function bindEvents() {
    $('#refreshBtn').addEventListener('click', () => refresh({ manual: true }));

    const auto = $('#autoRefresh');
    try { auto.checked = localStorage.getItem(AUTO_KEY) !== 'off'; } catch { /* keep default */ }
    auto.addEventListener('change', () => {
      try { localStorage.setItem(AUTO_KEY, auto.checked ? 'on' : 'off'); } catch { /* not persisted */ }
    });

    $('#view').addEventListener('input', (e) => {
      if (e.target.id === 'serverSearch') {
        state.search = e.target.value;
        updateServerGrid();
      }
    });
    $('#view').addEventListener('change', (e) => {
      if (e.target.id === 'serverSort') {
        state.sort = e.target.value;
        updateServerGrid();
      }
    });

    $('#authForm').addEventListener('submit', (e) => {
      e.preventDefault();
      const value = $('#authToken').value.trim();
      if (!value) return;
      writeToken(value);
      $('#authToken').value = '';
      hideAuth();
      refresh({ manual: true });
    });

    window.addEventListener('hashchange', () => {
      state.notFound = false;
      render(currentRoute(), { force: true });
      refresh();
    });

    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') refresh();
    });
  }

  function mountIcons() {
    document.querySelectorAll('[data-icon]').forEach((el) => {
      el.innerHTML = icon(el.dataset.icon, 18);
    });
    // Shared gradient for the server rings.
    const defs = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    defs.setAttribute('width', '0');
    defs.setAttribute('height', '0');
    defs.style.position = 'absolute';
    defs.innerHTML = `<defs><linearGradient id="ringGrad" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#3b82f6"/><stop offset="55%" stop-color="#b65ce6"/><stop offset="100%" stop-color="#ef4f5a"/></linearGradient></defs>`;
    document.body.appendChild(defs);
    $('#dbName').textContent = 'levidatabase.json';
  }

  async function boot() {
    mountIcons();
    bindEvents();
    setChrome(currentRoute());
    await refresh();
    setInterval(() => {
      if ($('#autoRefresh').checked && document.visibilityState === 'visible' && !state.authPending) refresh();
    }, REFRESH_MS);
    setInterval(tick, 1000);
  }

  boot();
})();
