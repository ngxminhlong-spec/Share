/* Noxy member dashboard.
   Shows only the signed-in member's own data and the settings of
   servers where the member has Manage Server. Settings changes go through the dashboard
   to the Noxy bot, which checks the permission again. Server text is escaped before it
   reaches the page. */
(() => {
  'use strict';

  const REFRESH_MS = 30000;
  const DISCORD_LOGIN = '/auth/login';
  const SNOWFLAKE = /^\d{15,25}$/;

  // ---------- helpers ----------

  const $ = (sel, root = document) => root.querySelector(sel);
  const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c]));
  const nf = new Intl.NumberFormat('en-US');
  const cf = new Intl.NumberFormat('en-US', { notation: 'compact', maximumFractionDigits: 1 });
  const num = (n) => {
    const v = Number(n) || 0;
    return Math.abs(v) >= 100000 ? cf.format(v) : nf.format(Math.round(v));
  };
  const pct = (n) => `${(Math.round((Number(n) || 0) * 10) / 10).toFixed(1).replace(/\.0$/, '')}%`;
  const plural = (n, word, many = `${word}s`) => (Number(n) === 1 ? word : many);

  function countdown(ms) {
    if (ms <= 0) return 'Ready';
    const s = Math.ceil(ms / 1000);
    const d = Math.floor(s / 86400);
    const h = Math.floor((s % 86400) / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    if (d) return `${d}d ${h}h`;
    if (h) return `${h}h ${String(m).padStart(2, '0')}m`;
    if (m) return `${m}m ${String(sec).padStart(2, '0')}s`;
    return `${sec}s`;
  }

  function ago(ms) {
    if (!ms) return 'Unknown time';
    const diff = Date.now() - ms;
    if (diff < 60000) return 'Just now';
    if (diff < 3600000) return `${Math.floor(diff / 60000)} min ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)} h ago`;
    if (diff < 30 * 86400000) return `${Math.floor(diff / 86400000)} days ago`;
    return new Date(ms).toLocaleDateString(undefined, { dateStyle: 'medium' });
  }

  const ICONS = window.NOXY_ICONS || {};
  const icon = (name, size = 18) => `<svg class="ico-svg" viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${ICONS[name] || ''}</svg>`;

  const guildBadge = (id) => `<span class="guild-badge" aria-hidden="true">${esc(String(id).slice(-2))}</span>`;
  const safeColor = (c) => (/^#[0-9a-fA-F]{6}$/.test(c || '') ? c : '#99aab5');

  // Reads a JSON response. Errors carry the bot's or server's message.
  async function apiJson(url, options = {}) {
    const res = await fetch(url, { cache: 'no-store', credentials: 'same-origin', ...options });
    let body = null;
    try { body = await res.json(); } catch { body = null; }
    if (!res.ok) {
      const err = new Error((body && body.error) || `Request failed (${res.status})`);
      err.status = res.status;
      throw err;
    }
    return body;
  }

  // ---------- state ----------

  const state = {
    health: null,
    loggedIn: false,
    profile: null,
    servers: null,        // { guilds: [...] } from /api/member/servers
    serversLoading: false,
    serversError: '',
    detail: null,         // { id, data } for the server being edited
    detailLoading: false,
    detailError: '',
    baseline: null,       // settings as last saved, used to find changes
    draft: null,          // what the form currently shows
    saving: false,
    saveMessage: '',
    saveFailed: false,
    sig: '',
    busy: false,
    error: '',
  };

  // ---------- routing ----------

  function parseRoute() {
    const parts = location.hash.replace(/^#\/?/, '').split('/').filter(Boolean);
    if (parts[0] === 'servers') {
      return { page: 'servers', id: parts[1] && SNOWFLAKE.test(parts[1]) ? parts[1] : null };
    }
    const page = ['analysis', 'terms'].includes(parts[0]) ? parts[0] : 'home';
    return { page, id: null };
  }

  const route = () => parseRoute().page;

  function notice(message, tone = 'info') {
    const el = $('#notice');
    el.hidden = !message;
    el.dataset.tone = tone;
    el.textContent = message || '';
  }

  // ---------- data ----------

  async function fetchMe() {
    const res = await fetch('/api/member/me', { cache: 'no-store', credentials: 'same-origin' });
    if (res.status === 401) return null;
    if (!res.ok) throw new Error(`Request failed (${res.status})`);
    return res.json();
  }

  async function refresh({ force = false } = {}) {
    if (state.busy) return;
    state.busy = true;
    try {
      if (!state.health) {
        state.health = await fetch('/api/health', { cache: 'no-store' }).then((r) => r.json()).catch(() => null);
      }
      const me = await fetchMe();
      state.loggedIn = Boolean(me);
      state.profile = me;
      state.overview = await fetch('/api/public/overview', { cache: 'no-store' }).then((r) => (r.ok ? r.json() : null)).catch(() => null);
      state.error = '';
    } catch (err) {
      state.error = 'Could not reach the server. Retrying…';
    } finally {
      state.busy = false;
      render({ force });
    }
  }

  // ---------- server settings ----------

  // The editable part of a server's settings, in a flat shape the form can bind to.
  function draftFrom(settings) {
    const w = settings.welcome || {};
    const g = settings.goodbye || {};
    const a = settings.automod || {};
    return {
      welcomeEnabled: !!w.enabled,
      welcomeChannelId: w.channelId || '',
      mainHeading: w.mainHeading || '',
      smallHeading: w.smallHeading || '',
      bio: w.bio || '',
      footerText: w.footerText || '',
      goodbyeEnabled: !!g.enabled,
      goodbyeChannelId: g.channelId || '',
      goodbyeMessage: g.message || '',
      autoroleIds: [...(settings.autoroleIds || [])],
      logChannelId: settings.logChannelId || '',
      amEnabled: !!a.enabled,
      amLinks: !!a.links,
      amInvites: !!a.invites,
      amCaps: !!a.caps,
      amMentions: Number(a.mentions) || 5,
      amSpamLimit: Number(a.spamLimit) || 5,
      amSpamWindow: Number(a.spamWindow) || 5,
      amPunishment: a.punishment || 'delete',
      disabledCommands: [...(settings.disabledCommands || [])],
    };
  }

  // Sends only the groups that changed. The bot validates every field it receives.
  function buildPatch(draft, base) {
    const changed = (keys) => keys.some((k) => JSON.stringify(draft[k]) !== JSON.stringify(base[k]));
    const patch = {};
    if (changed(['welcomeEnabled', 'welcomeChannelId', 'mainHeading', 'smallHeading', 'bio', 'footerText'])) {
      patch.welcome = {
        enabled: draft.welcomeEnabled,
        channelId: draft.welcomeChannelId || null,
        mainHeading: draft.mainHeading,
        smallHeading: draft.smallHeading,
        bio: draft.bio,
        footerText: draft.footerText,
      };
    }
    if (changed(['goodbyeEnabled', 'goodbyeChannelId', 'goodbyeMessage'])) {
      patch.goodbye = {
        enabled: draft.goodbyeEnabled,
        channelId: draft.goodbyeChannelId || null,
        message: draft.goodbyeMessage,
      };
    }
    if (changed(['autoroleIds'])) patch.autoroleIds = draft.autoroleIds;
    if (changed(['logChannelId'])) patch.logChannelId = draft.logChannelId || null;
    if (changed(['amEnabled', 'amLinks', 'amInvites', 'amCaps', 'amMentions', 'amSpamLimit', 'amSpamWindow', 'amPunishment'])) {
      patch.automod = {
        enabled: draft.amEnabled,
        links: draft.amLinks,
        invites: draft.amInvites,
        caps: draft.amCaps,
        mentions: draft.amMentions,
        spamLimit: draft.amSpamLimit,
        spamWindow: draft.amSpamWindow,
        punishment: draft.amPunishment,
      };
    }
    if (changed(['disabledCommands'])) patch.disabledCommands = draft.disabledCommands;
    return patch;
  }

  const isDirty = () => Boolean(state.draft && state.baseline && JSON.stringify(state.draft) !== JSON.stringify(state.baseline));

  async function loadServers() {
    state.serversLoading = true;
    state.serversError = '';
    render({ force: true });
    try {
      state.servers = await apiJson('/api/member/servers');
    } catch (err) {
      state.servers = null;
      state.serversError = sessionMessage(err);
    } finally {
      state.serversLoading = false;
      render({ force: true });
    }
  }

  async function loadServer(id) {
    state.detailLoading = true;
    state.detail = null;
    state.detailError = '';
    state.draft = null;
    state.baseline = null;
    state.saveMessage = '';
    render({ force: true });
    try {
      const data = await apiJson(`/api/member/servers/${id}`);
      if (parseRoute().id !== id) return;  // the member has moved on to another server
      state.detail = { id, data };
      state.baseline = draftFrom(data.settings);
      state.draft = { ...state.baseline };
    } catch (err) {
      if (parseRoute().id === id) state.detailError = sessionMessage(err);
    } finally {
      state.detailLoading = false;
      render({ force: true });
    }
  }

  async function saveServer() {
    if (!state.detail || !state.draft || state.saving) return;
    const patch = buildPatch(state.draft, state.baseline);
    if (!Object.keys(patch).length) {
      state.saveMessage = 'Nothing has changed.';
      state.saveFailed = false;
      render({ force: true });
      return;
    }
    state.saving = true;
    state.saveMessage = '';
    render({ force: true });
    try {
      const data = await apiJson(`/api/member/servers/${state.detail.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(patch),
      });
      state.detail = { id: state.detail.id, data };
      state.baseline = draftFrom(data.settings);
      state.draft = { ...state.baseline };
      state.saveMessage = 'Saved. The change is live in your server.';
      state.saveFailed = false;
    } catch (err) {
      // Keep the member's edits so they can fix the problem and try again.
      state.saveMessage = sessionMessage(err);
      state.saveFailed = true;
    } finally {
      state.saving = false;
      render({ force: true });
    }
  }

  function discardChanges() {
    if (!state.baseline) return;
    state.draft = { ...state.baseline };
    state.saveMessage = '';
    render({ force: true });
  }

  // A 401 means the login ended. Say so, and show the page as signed out.
  function sessionMessage(err) {
    if (err.status === 401) {
      state.loggedIn = false;
      return 'Your login has ended. Log in again to continue.';
    }
    return err.message || 'Something went wrong. Try again.';
  }

  // Runs when the page opens or the hash changes. Settings are only re-fetched on navigation,
  // so the 30-second refresh does not overwrite what the member is typing.
  function enterRoute() {
    if (!state.loggedIn) return;
    const { page, id } = parseRoute();
    if (page === 'servers') {
      if (id) loadServer(id);
      else loadServers();
    }
  }

  // ---------- rendering ----------

  function tile(iconName, label, value, note, tone = '') {
    return `
      <div class="card stat ${tone}">
        <div class="stat-top"><span class="stat-ico">${icon(iconName, 18)}</span><span class="stat-label">${esc(label)}</span></div>
        <div class="stat-value">${typeof value === 'number' ? num(value) : esc(value)}</div>
        <div class="stat-note">${esc(note)}</div>
      </div>`;
  }

  function viewLanding() {
    const configured = state.health ? state.health.memberLogin !== false : true;
    return `
      <section class="landing">
        <div class="landing-copy">
          <img class="logo-xl" src="logo.png" alt="Noxy logo" width="96" height="96">
          <span class="eyebrow">Noxy member dashboard</span>
          <h1>Your whole Noxy profile, <span class="grad">in one place</span></h1>
          <p class="lead">See your level and XP, how you're doing in each server, and change server settings if you manage one.</p>
          <div class="cta">
            ${configured
              ? `<a class="btn discord" href="${DISCORD_LOGIN}">${icon('login', 18)}<span>Log in with Discord</span></a>`
              : `<span class="btn discord" aria-disabled="true">${icon('login', 18)}<span>Login not set up yet</span></span>`}
            <span class="fine">We only ask for your Discord name and avatar.</span>
          </div>
        </div>
        <div class="landing-grid">
          <div class="card feature">
            <span class="feature-ico">${icon('sparkles', 20)}</span>
            <h3>Track your level</h3>
            <p>Watch your XP climb toward the next level, with a clear progress bar.</p>
          </div>
          <div class="card feature">
            <span class="feature-ico">${icon('activity', 20)}</span>
            <h3>See your analysis</h3>
            <p>Your messages, warnings and infractions in each server.</p>
          </div>
          <div class="card feature">
            <span class="feature-ico">${icon('server', 20)}</span>
            <h3>Manage your servers</h3>
            <p>Welcome messages, join roles, AutoMod and disabled commands, for servers where you have Manage Server.</p>
          </div>
        </div>
      </section>`;
  }

  function overviewValue(key) {
    const o = state.overview;
    return o && typeof o[key] === 'number' ? num(o[key]) : '—';
  }

  function viewHome() {
    return `
      <section class="hero card">
        <div class="hero-id">
          <div class="avatar-ring"><img src="logo.png" alt="" width="96" height="96"></div>
          <div class="hero-text">
            <span class="eyebrow">Discord bot</span>
            <h1>Noxy</h1>
            <p class="lead">Anti-nuke protection and all-in-one management for your Discord server: moderation, AutoMod, tickets, giveaways and fun commands.</p>
            <div class="cta" style="margin-top:18px">
              <a class="btn discord" href="https://discord.com/oauth2/authorize?client_id=1551780857822314578&scope=bot%20applications.commands" target="_blank" rel="noopener">${icon('bot', 18)}<span>Add Noxy to your server</span></a>
              <a class="btn" href="https://discord.gg/PcctraEAMF" target="_blank" rel="noopener">${icon('users', 18)}<span>Support server</span></a>
            </div>
          </div>
        </div>
      </section>

      <section>
        <div class="section-head"><h2>Noxy right now</h2></div>
        <div class="landing-grid stats-grid">
          <div class="card feature"><span class="feature-ico">${icon('server', 20)}</span><h3>Servers</h3><p class="stat-big">${overviewValue('servers')}</p></div>
          <div class="card feature"><span class="feature-ico">${icon('users', 20)}</span><h3>Members</h3><p class="stat-big">${overviewValue('members')}</p></div>
          <div class="card feature"><span class="feature-ico">${icon('message', 20)}</span><h3>Messages counted</h3><p class="stat-big">${overviewValue('messages')}</p></div>
          <div class="card feature"><span class="feature-ico">${icon('terminal', 20)}</span><h3>Commands run</h3><p class="stat-big">${overviewValue('commands')}</p></div>
        </div>
        <small class="faint">Totals across all servers that use Noxy. Updated when the bot saves its data.</small>
      </section>

      <section>
        <div class="section-head"><h2>What Noxy does</h2></div>
        <div class="landing-grid">
          <div class="card feature"><span class="feature-ico">${icon('shield', 20)}</span><h3>Anti-nuke</h3><p>Protects your server from raids and mass changes.</p></div>
          <div class="card feature"><span class="feature-ico">${icon('alert', 20)}</span><h3>Moderation</h3><p>Warnings and infractions with a clear record for every member.</p></div>
          <div class="card feature"><span class="feature-ico">${icon('message', 20)}</span><h3>AutoMod</h3><p>Automatic moderation of messages.</p></div>
          <div class="card feature"><span class="feature-ico">${icon('ticket', 20)}</span><h3>Tickets</h3><p>Support tickets for your members.</p></div>
          <div class="card feature"><span class="feature-ico">${icon('gift', 20)}</span><h3>Giveaways</h3><p>Giveaways for your members.</p></div>
          <div class="card feature"><span class="feature-ico">${icon('sparkles', 20)}</span><h3>Fun commands</h3><p>Games and everyday commands that keep members active.</p></div>
        </div>
      </section>

      <section>
        <div class="section-head"><h2>Your account</h2></div>
        <div class="landing-grid">
          <a class="card feature" href="#/servers"><span class="feature-ico">${icon('server', 20)}</span><h3>Your servers</h3><p>Change welcome messages, join roles, AutoMod and disabled commands where you have Manage Server.</p></a>
          <a class="card feature" href="#/analysis"><span class="feature-ico">${icon('activity', 20)}</span><h3>Your analysis</h3><p>Your messages, warnings and infractions in each server.</p></a>
          <a class="card feature" href="#/terms"><span class="feature-ico">${icon('book', 20)}</span><h3>Terms and privacy</h3><p>What we collect, how it is used, and the rules for using this dashboard.</p></a>
        </div>
      </section>`;
  }

  function viewTerms() {
    return `
      <article class="card legal">
        <span class="eyebrow">Legal</span>
        <h1>Terms of Service and Privacy Policy</h1>
        <p class="meta">Last updated: 2026-11-26</p>

        <h2>Terms of Service</h2>
        <ol>
          <li><b>About this dashboard.</b> The Noxy dashboard lets you see your own Noxy profile and analysis, and lets people with the Manage Server permission change the settings of servers where the Noxy bot is installed. It is run by [operator name] for the Noxy Discord bot.</li>
          <li><b>Who can use it.</b> You must have a Discord account and log in with Discord. You may only see your own data. To change a server's settings you must have Manage Server, Administrator, or be the server owner. The bot checks this again on every change.</li>
          <li><b>Acceptable use.</b> Do not try to see other members' data, get around the login or permission checks, overload the service, or use the dashboard to harm a server or its members.</li>
          <li><b>Server settings.</b> Changes you save are applied to the server by the Noxy bot, and you are responsible for them. We may limit or undo a change that breaks the bot or breaks Discord's rules.</li>
          <li><b>The service.</b> We may change, pause or stop the dashboard or the bot at any time. The dashboard is provided "as is". Data can lag behind the bot, and availability is not guaranteed.</li>
          <li><b>Discord.</b> Noxy and this dashboard are not made by, affiliated with, or endorsed by Discord. You must follow Discord's Terms of Service and Community Guidelines.</li>
          <li><b>Liability.</b> To the extent the law allows, we are not liable for indirect or consequential losses from using the dashboard or the bot.</li>
          <li><b>Changes.</b> We may update these terms. The date at the top shows the latest version. Continuing to use the dashboard means you accept the changes.</li>
          <li><b>Contact.</b> [contact email]</li>
        </ol>

        <h2>Privacy Policy</h2>
        <h3>What we collect</h3>
        <ul>
          <li><b>When you log in with Discord</b> we get your Discord user ID, username, display name and avatar (the <code>identify</code> scope). We do not ask for your email, your password, your messages or your friends list.</li>
          <li><b>From the Noxy bot's database</b> we read your level and XP, message counts per server, and any warnings and infractions you have received. Moderator IDs are not shown to you.</li>
          <li><b>When you change a server's settings</b> the bot stores the new settings for that server.</li>
        </ul>

        <h3>How we use it</h3>
        <p>To show your profile and analysis, to let you manage servers where you have permission, and to keep the service secure. We read the bot's data and never change your data from the dashboard.</p>

        <h3>Cookies and sessions</h3>
        <ul>
          <li><code>noxy_session</code>: keeps you logged in. It is HttpOnly and SameSite=Lax, and lasts 7 days. Sessions are kept in server memory, so you are logged out when the server restarts or when you log out.</li>
          <li><code>noxy_oauth_state</code>: a short-lived, single-use cookie that protects the Discord login from forgery.</li>
          <li>We do not use advertising cookies, third-party trackers or third-party scripts.</li>
        </ul>

        <h3>Staff access</h3>
        <p>The operator of the Noxy bot has a separate staff dashboard. It shows member IDs, warning reasons and moderation history for the servers the bot runs in. Access to it is protected by a token.</p>

        <h3>Sharing</h3>
        <p>We do not sell your data. We do not share it with third parties, except where the law requires it or where a service provider runs the hosting for us under a confidentiality agreement.</p>

        <h3>How long we keep it</h3>
        <p>Login sessions end after 7 days, on logout, or on restart. Bot data is kept for as long as the server uses Noxy, or until it is deleted on request.</p>

        <h3>Your rights</h3>
        <p>You can ask to see, correct or delete your data. Email [contact email]. Deleting bot records may require the bot to delete them too, and we will tell you if that happens.</p>

        <h3>Security</h3>
        <p>The dashboard should run behind HTTPS. Secrets such as the Discord client secret and the bot's internal key are kept in server environment settings, not in the code.</p>

        <h3>Children</h3>
        <p>Discord requires users to be at least 13. We do not knowingly collect data from anyone younger.</p>

        <h3>Changes and contact</h3>
        <p>We may update this policy. The date at the top shows the latest version. Questions: [contact email].</p>
      </article>`;
  }

  function viewAnalysis(p) {
    const servers = p.servers;
    const totals = servers.reduce((t, s) => ({
      messages: t.messages + s.messages,
      warnings: t.warnings + s.warnings.length,
      infractions: t.infractions + s.infractions.length,
    }), { messages: 0, warnings: 0, infractions: 0 });

    if (!servers.length) {
      return `<div class="empty card">${icon('activity', 22)}<p>No activity yet. Send a message in a server that uses Noxy and it will show up here.</p></div>`;
    }

    const cards = servers.map((s) => `
      <article class="card server">
        <header class="server-head">
          ${guildBadge(s.id)}
          <div class="server-title"><b>Server ${esc(s.id)}</b><small>${num(s.messages)} ${plural(s.messages, 'message')} sent</small></div>
          <div class="server-badges">
            ${s.warnings.length ? `<span class="badge warn">${icon('alert', 12)}${num(s.warnings.length)} ${plural(s.warnings.length, 'warning')}</span>` : '<span class="badge ok">Good standing</span>'}
          </div>
        </header>
        ${s.warnings.length || s.infractions.length ? `
          <div class="records">
            ${s.warnings.length ? `
              <details>
                <summary>Warnings <span class="count">${num(s.warnings.length)}</span></summary>
                <ul>${s.warnings.map((w) => `<li><span class="rec-main">${esc(w.reason || 'No reason given')}</span><span class="rec-time">${esc(ago(w.at))}</span></li>`).join('')}</ul>
              </details>` : ''}
            ${s.infractions.length ? `
              <details>
                <summary>Infractions <span class="count">${num(s.infractions.length)}</span></summary>
                <ul>${s.infractions.map((r) => `<li><span class="rec-main"><b>${esc(r.type || 'Action')}</b>${r.reason ? ` · ${esc(r.reason)}` : ''}</span><span class="rec-time">${esc(ago(r.at))}</span></li>`).join('')}</ul>
              </details>` : ''}
          </div>` : ''}
      </article>`).join('');

    return `
      <section class="stats three">
        ${tile('message', 'Messages', totals.messages, 'Across all servers')}
        ${tile('alert', 'Warnings', totals.warnings, totals.warnings ? 'Read them below' : 'You have none', totals.warnings ? 'warn' : '')}
        ${tile('shield', 'Infractions', totals.infractions, totals.infractions ? 'Read them below' : 'You have none', totals.infractions ? 'warn' : '')}
      </section>
      <section>
        <div class="section-head"><h2>By server</h2><span class="faint small">${num(servers.length)} ${plural(servers.length, 'server')}</span></div>
        <div class="servers">${cards}</div>
      </section>`;
  }

  function viewServers() {
    if (state.serversLoading && !state.servers) {
      return `<section class="card lb"><div class="empty plain">Loading your servers…</div></section>`;
    }
    if (state.serversError) {
      return `
        <section class="card form-card">
          <div class="section-head"><h2>Your servers</h2></div>
          <div class="empty plain">${icon('alert', 22)}<p>${esc(state.serversError)}</p></div>
        </section>`;
    }
    const guilds = (state.servers && state.servers.guilds) || [];
    const intro = `
      <div class="page-head">
        <div>
          <span class="eyebrow">Server settings</span>
          <h1>Your servers</h1>
          <p class="lead">Servers where you have Manage Server and Noxy is installed.</p>
        </div>
      </div>`;
    if (!guilds.length) {
      return `${intro}
        <div class="empty card">${icon('server', 22)}<p>No servers to manage yet. You need Manage Server permission in a server where Noxy is installed.</p></div>`;
    }
    const cards = guilds.map((g) => `
      <a class="card guild-card" href="#/servers/${esc(g.id)}">
        <span class="guild-icon">${g.icon
          ? `<img src="${esc(g.icon)}" alt="" width="56" height="56" referrerpolicy="no-referrer">`
          : `<span aria-hidden="true">${esc(String(g.name || '?').charAt(0).toUpperCase())}</span>`}</span>
        <span class="guild-meta">
          <b>${esc(g.name)}</b>
          <small>${num(g.memberCount)} ${plural(g.memberCount, 'member')}</small>
        </span>
        <span class="guild-go">${icon('chevron', 18)}</span>
      </a>`).join('');
    return `${intro}<div class="guild-grid">${cards}</div>`;
  }

  // ---- servers: one server's settings ----

  const selectOptions = (items, selected, emptyLabel) => [
    `<option value="" ${selected ? '' : 'selected'}>${esc(emptyLabel)}</option>`,
    ...items.map((c) => `<option value="${esc(c.id)}" ${c.id === selected ? 'selected' : ''}>#${esc(c.name)}</option>`),
  ].join('');

  function viewServerDetail() {
    if (state.detailLoading) {
      return `<section class="card lb"><div class="empty plain">Loading settings…</div></section>`;
    }
    if (state.detailError) {
      return `
        <section class="card form-card">
          <a class="btn ghost sm back" href="#/servers">${icon('back', 16)}<span>All servers</span></a>
          <div class="empty plain">${icon('alert', 22)}<p>${esc(state.detailError)}</p></div>
        </section>`;
    }
    if (!state.detail || !state.draft) {
      return `<section class="card lb"><div class="empty plain">Pick a server to edit.</div></section>`;
    }

    const { guild, options } = state.detail.data;
    const d = state.draft;
    const dirty = isDirty();
    const channels = options.channels || [];
    const roles = options.roles || [];
    const commands = options.commands || [];
    const picked = d.autoroleIds.length;

    const roleList = roles.length
      ? roles.map((r) => `
          <label class="check role-check">
            <input type="checkbox" data-list="autoroleIds" data-value="${esc(r.id)}" ${d.autoroleIds.includes(r.id) ? 'checked' : ''} ${!d.autoroleIds.includes(r.id) && picked >= 10 ? 'disabled' : ''}>
            <span class="swatch" style="background:${esc(safeColor(r.color))}"></span>
            <span>${esc(r.name)}</span>
          </label>`).join('')
      : '<p class="faint small">No roles to choose from.</p>';

    const cmdList = commands.length
      ? commands.map((c) => `
          <label class="check ${c.protected ? 'is-locked' : ''}">
            <input type="checkbox" data-list="disabledCommands" data-value="${esc(c.name)}" ${d.disabledCommands.includes(c.name) ? 'checked' : ''} ${c.protected ? 'disabled' : ''}>
            <span>n?${esc(c.name)}</span>
            ${c.protected ? `<small class="faint">${icon('lock', 12)} always on</small>` : ''}
          </label>`).join('')
      : '<p class="faint small">No commands to show.</p>';

    return `
      <div class="page-head">
        <a class="btn ghost sm back" href="#/servers" data-back>${icon('back', 16)}<span>All servers</span></a>
        <div class="guild-head">
          <span class="guild-icon big">${guild.icon
            ? `<img src="${esc(guild.icon)}" alt="" width="64" height="64" referrerpolicy="no-referrer">`
            : `<span aria-hidden="true">${esc(String(guild.name || '?').charAt(0).toUpperCase())}</span>`}</span>
          <div>
            <h1>${esc(guild.name)}</h1>
            <p class="faint small">${num(guild.memberCount)} ${plural(guild.memberCount, 'member')} · Changes apply right away</p>
          </div>
        </div>
      </div>

      ${state.saveMessage ? `<div class="form-note ${state.saveFailed ? 'bad' : 'good'}" role="status">${state.saveFailed ? icon('alert', 16) : icon('check', 16)}<span>${esc(state.saveMessage)}</span></div>` : ''}

      <section class="card form-card">
        <div class="section-head"><h2>Welcome messages</h2></div>
        <label class="toggle"><input type="checkbox" data-field="welcomeEnabled" ${d.welcomeEnabled ? 'checked' : ''}><span>Send a welcome message when someone joins</span></label>
        <div class="grid-2">
          <label class="field"><span>Channel</span><select data-field="welcomeChannelId">${selectOptions(channels, d.welcomeChannelId, 'No channel')}</select></label>
          <label class="field"><span>Main headline</span><input type="text" maxlength="256" data-field="mainHeading" value="${esc(d.mainHeading)}"></label>
          <label class="field"><span>Small headline</span><input type="text" maxlength="256" data-field="smallHeading" value="${esc(d.smallHeading)}"></label>
          <label class="field"><span>Footer text</span><input type="text" maxlength="200" data-field="footerText" value="${esc(d.footerText)}"></label>
        </div>
        <label class="field"><span>Welcome message <small class="faint">${esc(String(d.bio).length)}/1000</small></span><textarea rows="3" maxlength="1000" data-field="bio">${esc(d.bio)}</textarea></label>
      </section>

      <section class="card form-card">
        <div class="section-head"><h2>Goodbye messages</h2></div>
        <label class="toggle"><input type="checkbox" data-field="goodbyeEnabled" ${d.goodbyeEnabled ? 'checked' : ''}><span>Post a message when someone leaves</span></label>
        <div class="grid-2">
          <label class="field"><span>Channel</span><select data-field="goodbyeChannelId">${selectOptions(channels, d.goodbyeChannelId, 'No channel')}</select></label>
          <label class="field"><span>Message</span><input type="text" maxlength="1000" data-field="goodbyeMessage" value="${esc(d.goodbyeMessage)}"></label>
        </div>
      </section>

      <section class="card form-card">
        <div class="section-head"><h2>Join roles</h2><span class="faint small">${picked} of 10 picked</span></div>
        <div class="check-grid">${roleList}</div>
      </section>

      <section class="card form-card">
        <div class="section-head"><h2>Moderation log</h2></div>
        <label class="field"><span>Log channel</span><select data-field="logChannelId">${selectOptions(channels, d.logChannelId, 'No log channel')}</select></label>
      </section>

      <section class="card form-card">
        <div class="section-head"><h2>AutoMod</h2></div>
        <label class="toggle"><input type="checkbox" data-field="amEnabled" ${d.amEnabled ? 'checked' : ''}><span>Turn AutoMod on</span></label>
        <div class="check-row">
          <label class="check"><input type="checkbox" data-field="amLinks" ${d.amLinks ? 'checked' : ''}><span>Block links</span></label>
          <label class="check"><input type="checkbox" data-field="amInvites" ${d.amInvites ? 'checked' : ''}><span>Block invites</span></label>
          <label class="check"><input type="checkbox" data-field="amCaps" ${d.amCaps ? 'checked' : ''}><span>Block shouting (caps)</span></label>
        </div>
        <div class="grid-4">
          <label class="field"><span>Mention limit</span><input type="number" min="1" max="20" data-field="amMentions" value="${esc(d.amMentions)}"></label>
          <label class="field"><span>Spam: messages</span><input type="number" min="2" max="20" data-field="amSpamLimit" value="${esc(d.amSpamLimit)}"></label>
          <label class="field"><span>Spam: seconds</span><input type="number" min="2" max="30" data-field="amSpamWindow" value="${esc(d.amSpamWindow)}"></label>
          <label class="field"><span>Punishment</span>
            <select data-field="amPunishment">
              ${[['delete', 'Delete message'], ['timeout', 'Timeout'], ['warn', 'Warn']].map(([v, l]) => `<option value="${v}" ${d.amPunishment === v ? 'selected' : ''}>${l}</option>`).join('')}
            </select>
          </label>
        </div>
      </section>

      <section class="card form-card">
        <div class="section-head"><h2>Disabled commands</h2><span class="faint small">${d.disabledCommands.length} off</span></div>
        <div class="check-grid cmd-grid">${cmdList}</div>
      </section>

      <div class="savebar ${dirty ? 'is-dirty' : ''}">
        <span class="faint small">${dirty ? 'You have unsaved changes.' : 'Everything is saved.'}</span>
        <div class="savebar-btns">
          <button type="button" class="btn ghost sm" id="discardBtn" ${dirty && !state.saving ? '' : 'disabled'}>${icon('x', 16)}<span>Discard</span></button>
          <button type="button" class="btn primary sm" id="saveBtn" ${dirty && !state.saving ? '' : 'disabled'}>${icon('check', 16)}<span>${state.saving ? 'Saving…' : 'Save changes'}</span></button>
        </div>
      </div>`;
  }

  function accountHtml() {
    const configured = state.health ? state.health.memberLogin !== false : true;
    if (!state.loggedIn || !state.profile) {
      return configured
        ? `<a class="btn discord sm" href="${DISCORD_LOGIN}">${icon('login', 16)}<span>Log in</span></a>`
        : '';
    }
    const u = state.profile.user;
    return `
      <div class="me">
        <img class="me-avatar" src="${esc(u.avatarUrl)}" alt="" width="34" height="34" referrerpolicy="no-referrer">
        <div class="me-text"><b>${esc(u.name)}</b><small>Level ${num(state.profile.level)}</small></div>
        <button type="button" class="btn ghost sm" id="logoutBtn">${icon('logout', 16)}<span>Log out</span></button>
      </div>`;
  }

  // Skip re-rendering when nothing changed, so the page does not flicker on refresh.
  function render({ force = false } = {}) {
    const { page, id } = parseRoute();
    const sig = JSON.stringify([state.loggedIn, state.profile, state.overview, state.error,
      location.hash, state.health && state.health.memberLogin,
      state.servers, state.serversError, state.serversLoading,
      state.detail, state.detailError, state.detailLoading, state.saveMessage, state.saveFailed, state.saving]);
    // The draft is deliberately left out: typing must not rebuild the form. updateSaveBar handles dirty state.
    if (!force && sig === state.sig) return;
    state.sig = sig;

    $('#account').innerHTML = accountHtml();
    const tabs = $('#tabs');
    tabs.hidden = !state.loggedIn;
    tabs.querySelectorAll('[data-tab]').forEach((a) => {
      if (a.dataset.tab === page) a.setAttribute('aria-current', 'page');
      else a.removeAttribute('aria-current');
    });

    const view = $('#view');
    view.classList.toggle('no-motion', !force);
    if (page === 'terms') {
      view.innerHTML = viewTerms();
    } else if (!state.loggedIn) {
      view.innerHTML = viewLanding();
    } else if (page === 'analysis') {
      view.innerHTML = viewAnalysis(state.profile);
    } else if (page === 'servers') {
      view.innerHTML = id ? viewServerDetail() : viewServers();
    } else {
      view.innerHTML = viewHome();
    }
    document.title = state.loggedIn && page === 'home' ? `Hi, ${state.profile.user.name} · Noxy` : 'Noxy · Your profile';
    notice(state.error, 'error');
  }

  // Updates the cooldown countdowns each second, and re-renders when one becomes ready.
  function tick() {
    if (!state.loggedIn || !state.profile) return;
    let becameReady = false;
    document.querySelectorAll('[data-ready-at]').forEach((el) => {
      const left = Number(el.dataset.readyAt) - Date.now();
      if (left <= 0 && !el.querySelector('.pill.ok')) becameReady = true;
      else if (left > 0) el.querySelector('.pill').textContent = countdown(left);
    });
    if (becameReady) render({ force: true });
  }

  // ---------- events ----------

  // Writes one form control's value into the draft. Typing does not re-render the form,
  // so the cursor stays where it is.
  function setField(el) {
    if (!state.draft) return;
    if (el.dataset.list) {
      const list = state.draft[el.dataset.list];
      const value = el.dataset.value;
      const index = list.indexOf(value);
      if (el.checked && index === -1) list.push(value);
      if (!el.checked && index !== -1) list.splice(index, 1);
      render({ force: true });  // checkbox limits (10 roles) and counts depend on the list
      return;
    }
    const key = el.dataset.field;
    if (!key) return;
    if (el.type === 'checkbox') state.draft[key] = el.checked;
    else if (el.type === 'number') state.draft[key] = Number(el.value);
    else state.draft[key] = el.value;
    updateSaveBar();
  }

  // Refreshes only the save bar and the character counter, so typing is not interrupted.
  function updateSaveBar() {
    const dirty = isDirty();
    const bar = document.querySelector('.savebar');
    if (!bar) return;
    bar.classList.toggle('is-dirty', dirty);
    bar.querySelector('.savebar-btns').innerHTML = `
      <button type="button" class="btn ghost sm" id="discardBtn" ${dirty && !state.saving ? '' : 'disabled'}>${icon('x', 16)}<span>Discard</span></button>
      <button type="button" class="btn primary sm" id="saveBtn" ${dirty && !state.saving ? '' : 'disabled'}>${icon('check', 16)}<span>${state.saving ? 'Saving…' : 'Save changes'}</span></button>`;
    bar.querySelector('span').textContent = dirty ? 'You have unsaved changes.' : 'Everything is saved.';
    const bio = document.querySelector('[data-field="bio"]');
    if (bio) {
      const counter = bio.closest('label').querySelector('small');
      if (counter) counter.textContent = `${bio.value.length}/1000`;
    }
  }

  function bind() {
    const onFormChange = (e) => {
      const el = e.target.closest('[data-field], [data-list]');
      if (el && el.closest('.form-card, .savebar')) setField(el);
    };
    document.addEventListener('input', (e) => {
      const el = e.target.closest('[data-field]');
      if (el && el.tagName !== 'SELECT' && el.type !== 'checkbox' && el.closest('.form-card')) setField(el);
    });
    document.addEventListener('change', onFormChange);

    document.addEventListener('click', async (e) => {
      if (e.target.closest('#saveBtn')) {
        e.preventDefault();
        saveServer();
        return;
      }
      if (e.target.closest('#discardBtn')) {
        e.preventDefault();
        discardChanges();
        return;
      }
      const back = e.target.closest('[data-back]');
      if (back && isDirty() && !confirm('Leave without saving your changes?')) {
        e.preventDefault();
        return;
      }
      if (e.target.closest('#logoutBtn')) {
        e.preventDefault();
        await fetch('/auth/logout', { method: 'POST', credentials: 'same-origin' }).catch(() => {});
        state.profile = null;
        state.loggedIn = false;
        state.servers = null;
        state.detail = null;
        state.draft = null;
        state.baseline = null;
        if (location.hash) history.replaceState(null, '', '/');
        render({ force: true });
      }
    });

    window.addEventListener('hashchange', () => {
      render({ force: true });
      enterRoute();
    });

    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') refresh();
    });

    // Warn before a reload or close throws away unsaved server changes.
    window.addEventListener('beforeunload', (e) => {
      if (isDirty()) {
        e.preventDefault();
        e.returnValue = '';
      }
    });
  }

  function showLoginResult() {
    const params = new URLSearchParams(location.search);
    const result = params.get('login');
    if (!result) return;
    const messages = {
      failed: ['Login did not work. Please try again.', 'error'],
      cancelled: ['Login was cancelled.', 'info'],
    };
    if (messages[result]) notice(messages[result][0], messages[result][1]);
    history.replaceState(null, '', location.pathname + location.hash);
  }

  async function boot() {
    document.querySelectorAll('[data-icon]').forEach((el) => { el.innerHTML = icon(el.dataset.icon, 18); });
    bind();
    showLoginResult();
    render({ force: true });
    await refresh({ force: true });
    enterRoute();
    setInterval(() => refresh(), REFRESH_MS);
    setInterval(tick, 1000);
  }

  boot();
})();
