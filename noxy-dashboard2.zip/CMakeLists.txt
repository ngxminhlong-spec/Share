cmake_minimum_required(VERSION 3.16)
project(noxy_dashboard LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

if(NOT CMAKE_BUILD_TYPE AND NOT CMAKE_CONFIGURATION_TYPES)
  set(CMAKE_BUILD_TYPE Release CACHE STRING "Build type" FORCE)
endif()

# ---- dependencies -----------------------------------------------------------
# Vendored in third_party/ (single-header, MIT). See third_party/README.md.
# No network access is needed at build time.
add_library(vendored_deps INTERFACE)
target_include_directories(vendored_deps SYSTEM INTERFACE
  ${CMAKE_CURRENT_SOURCE_DIR}/third_party)

find_package(Threads REQUIRED)

# ---- library: pure stats code (shared by the server and the tests) ----------
add_library(noxy_core STATIC
  src/stats.cpp
  src/database_store.cpp
)
target_include_directories(noxy_core PUBLIC src)
target_link_libraries(noxy_core PUBLIC vendored_deps)

# ---- server -----------------------------------------------------------------
# OpenSSL is needed only by the server: it calls Discord over HTTPS to finish member login.
find_package(OpenSSL REQUIRED)
add_executable(noxy-dashboard src/main.cpp src/discord_auth.cpp src/bot_api.cpp)
target_compile_definitions(noxy-dashboard PRIVATE CPPHTTPLIB_OPENSSL_SUPPORT)
target_link_libraries(noxy-dashboard PRIVATE OpenSSL::SSL OpenSSL::Crypto)
target_link_libraries(noxy-dashboard PRIVATE noxy_core Threads::Threads)
if(WIN32)
  target_link_libraries(noxy-dashboard PRIVATE ws2_32 crypt32)
endif()

if(CMAKE_CXX_COMPILER_ID MATCHES "GNU|Clang")
  target_compile_options(noxy_core PRIVATE -Wall -Wextra -Wpedantic)
  target_compile_options(noxy-dashboard PRIVATE -Wall -Wextra -Wpedantic)
endif()

# ---- tests ------------------------------------------------------------------
enable_testing()
add_executable(stats_tests tests/stats_tests.cpp)
target_link_libraries(stats_tests PRIVATE noxy_core)
add_test(NAME stats_tests COMMAND stats_tests "${CMAKE_CURRENT_SOURCE_DIR}/tests/fixtures")
