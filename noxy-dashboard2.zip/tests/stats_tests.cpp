// stats_tests.cpp
// Checks the aggregation logic against tests/fixtures/levidatabase.json.
// Expected values were worked out by hand from that fixture.
#include "database_store.hpp"
#include "stats.hpp"

#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>

namespace fs = std::filesystem;
using noxy::json;

static int failures = 0;
static int checks = 0;

#define CHECK(cond)                                                                \
    do {                                                                           \
        ++checks;                                                                  \
        if (!(cond)) {                                                             \
            ++failures;                                                            \
            std::cerr << __FILE__ << ":" << __LINE__ << ": CHECK failed: " #cond "\n"; \
        }                                                                          \
    } while (0)

static bool nearly(double a, double b) { return std::abs(a - b) < 1e-9; }

static json loadFixture(const fs::path& file) {
    std::ifstream in(file);
    if (!in) {
        std::cerr << "cannot open fixture: " << file << "\n";
        std::exit(2);
    }
    return json::parse(in);
}

static void testSummary(const json& db) {
    noxy::SourceInfo src;
    src.fileBytes = 1234;
    src.fileModifiedMs = 1000000;
    src.nowMs = 1060000;
    const json s = noxy::buildSummary(db, src);

    CHECK(s["database"]["guildCount"] == 2);
    CHECK(s["database"]["userCount"] == 3);
    CHECK(s["database"]["ageMs"] == 60000);
    CHECK(s["bot"]["trackingSince"] == 1000);
    CHECK(s["bot"]["trackingMs"] == 1059000);
    CHECK(s["bot"]["uniqueCommands"] == 3);
    CHECK(s["bot"]["noPrefixUsers"] == 1);
    CHECK(s["bot"]["supportConfigured"] == false);

    CHECK(s["totals"]["messages"] == 18);      // 15 in 1001 + 3 in 1002
    CHECK(s["totals"]["commands"] == 17);      // global counter: 4 + 4 + 9
    CHECK(s["totals"]["commandsByServer"] == 7);
    CHECK(s["totals"]["warnings"] == 2);
    CHECK(s["totals"]["infractions"] == 1);
    CHECK(s["totals"]["openTickets"] == 1);
    CHECK(s["totals"]["activeGiveaways"] == 1);
    CHECK(s["totals"]["coins"] == 130);
    CHECK(s["totals"]["bank"] == 1050);
    CHECK(s["totals"]["wealth"] == 1180);
    CHECK(s["totals"]["xp"] == 510);
    CHECK(s["totals"]["wins"] == 2);
    CHECK(s["totals"]["games"] == 4);

    // Top commands: highest count first; ties sorted alphabetically.
    CHECK(s["topCommands"].size() == 3);
    CHECK(s["topCommands"][0]["name"] == "stats");
    CHECK(s["topCommands"][1]["name"] == "help");
    CHECK(s["topCommands"][2]["name"] == "ping");

    // Guild list: most messages first.
    CHECK(s["topGuilds"].size() == 2);
    CHECK(s["topGuilds"][0]["id"] == "1001");
    CHECK(s["topGuilds"][0]["messages"] == 15);
    CHECK(s["topGuilds"][0]["features"] == 6);
    CHECK(s["topGuilds"][0]["starred"] == 2);
    CHECK(s["topGuilds"][1]["id"] == "1002");
    CHECK(s["topGuilds"][1]["features"] == 1);

    // Moderation: only 1001 has warnings or infractions (2 + 1).
    CHECK(s["topModerated"].size() == 1);
    CHECK(s["topModerated"][0]["id"] == "1001");
    CHECK(s["topModerated"][0]["infractions"] == 1);

    // Feature adoption: welcome is on in 1 of 2 guilds.
    bool sawWelcome = false;
    for (const auto& f : s["features"]) {
        if (f["key"] == "welcome") {
            sawWelcome = true;
            CHECK(f["guilds"] == 1);
            CHECK(nearly(f["percent"].get<double>(), 50.0));
        }
        if (f["key"] == "automod") CHECK(f["guilds"] == 0);
    }
    CHECK(sawWelcome);
    CHECK(s["features"].size() == 24);
}

static void testGuildDetail(const json& db) {
    const json d = noxy::buildGuildDetail(db, "1001", 1060000);
    CHECK(!d.is_null());
    CHECK(d["summary"]["warnings"] == 2);
    CHECK(d["summary"]["totalTickets"] == 2);

    // Warnings are newest first.
    CHECK(d["warnings"].size() == 2);
    CHECK(d["warnings"][0]["reason"] == "caps");
    CHECK(d["warnings"][0]["at"] == 3);
    CHECK(d["warnings"][1]["reason"] == "spam");

    CHECK(d["infractions"].size() == 1);
    CHECK(d["infractions"][0]["type"] == "timeout");

    // Tickets: largest channel ID first (Discord IDs grow over time).
    CHECK(d["tickets"][0]["channelId"] == "c2");
    CHECK(d["tickets"][0]["claimed"] == true);
    CHECK(d["tickets"][0]["ownerId"] == "u2");
    CHECK(d["tickets"][1]["channelId"] == "c1");
    CHECK(d["tickets"][1]["claimed"] == false);

    // Giveaways: latest end time first.
    CHECK(d["giveaways"][0]["prize"] == "Nitro");
    CHECK(d["giveaways"][1]["finished"] == true);

    CHECK(d["topChatters"][0]["userId"] == "u1");
    CHECK(d["topChatters"][0]["messages"] == 10);

    CHECK(d["antiNuke"]["windowSeconds"] == 10);
    CHECK(d["antiNuke"]["events"] == 1);
    // Nested objects are skipped in recent events; scalar fields stay.
    const json& fields = d["antiNuke"]["recent"][0]["fields"];
    bool hasNested = false;
    bool hasType = false;
    for (const auto& f : fields) {
        if (f["key"] == "extra") hasNested = true;
        if (f["key"] == "type") hasType = true;
    }
    CHECK(!hasNested);
    CHECK(hasType);

    CHECK(d["automod"]["badwords"] == 2);  // counted, never returned as words
    CHECK(d["automod"]["timeoutSeconds"] == 60);
    CHECK(d["customCommands"][0] == "hi");

    CHECK(noxy::buildGuildDetail(db, "9999", 0).is_null());
}

static void testEconomy(const json& db) {
    const json e = noxy::buildEconomy(db);
    CHECK(e["totals"]["users"] == 3);
    CHECK(e["totals"]["wealth"] == 1180);
    CHECK(nearly(e["totals"]["winRate"].get<double>(), 50.0));
    CHECK(nearly(e["totals"]["averageLevel"].get<double>(), 16.0 / 3.0));

    // Leaderboard by wealth: u2 (1000), u1 (150), u3 (30).
    CHECK(e["leaderboard"][0]["userId"] == "u2");
    CHECK(e["leaderboard"][1]["userId"] == "u1");
    CHECK(e["leaderboard"][2]["userId"] == "u3");

    // Level buckets: u3 is level 1 (default), u1 is 3, u2 is 12.
    CHECK(e["levels"][0]["count"] == 1);
    CHECK(e["levels"][1]["count"] == 1);
    CHECK(e["levels"][2]["count"] == 0);
    CHECK(e["levels"][3]["count"] == 1);
    CHECK(e["levels"][5]["count"] == 0);

    // Fish: 2 (u1) + 1 (u2) = 3 across 2 holders. Gem: 1 across 1 holder.
    CHECK(e["inventory"][0]["name"] == "Fish");
    CHECK(e["inventory"][0]["total"] == 3);
    CHECK(e["inventory"][0]["holders"] == 2);
    CHECK(e["inventory"][1]["name"] == "Gem");
}

static void testSerialization() {
    // Invalid UTF-8 must not throw; it is replaced with U+FFFD.
    json bad = json::object();
    bad["text"] = std::string("ok\xff!");
    const std::string out = noxy::dumpJson(bad);
    CHECK(out.find("\xEF\xBF\xBD") != std::string::npos);
    CHECK(out.find("ok") != std::string::npos);
}

static void testMember(const json& db) {
    // u1: level 3, 100 coins + 50 banked, in 1001 (10 msgs, 2 warnings) and 1002 (3 msgs).
    const json p = noxy::buildMemberProfile(db, "u1", 1060000);
    CHECK(p["hasProfile"] == true);
    CHECK(p["level"] == 3);
    CHECK(p["xpNeeded"] == 300);
    CHECK(p["wealth"] == 150);
    CHECK(nearly(p["stats"]["winRate"].get<double>(), 50.0));
    CHECK(p["inventory"].size() == 2);
    CHECK(p["inventory"][0]["name"] == "Fish");
    CHECK(p["inventory"][0]["qty"] == 2);
    CHECK(p["rank"] == 2);           // u2 has more wealth
    CHECK(p["rankTotal"] == 3);
    CHECK(p["cooldowns"]["work"]["readyAt"] == 3600000);
    CHECK(p["cooldowns"]["fish"]["readyAt"] == 300000);
    CHECK(p["cooldowns"]["crime"]["readyAt"] == 600000);
    CHECK(p["servers"].size() == 2);
    CHECK(p["servers"][0]["id"] == "1001");        // most messages first
    CHECK(p["servers"][0]["messages"] == 10);
    CHECK(p["servers"][0]["warnings"].size() == 2);
    CHECK(p["servers"][0]["warnings"][0]["reason"] == "caps");  // newest first
    CHECK(p["servers"][1]["id"] == "1002");

    // Moderator IDs and other members' entries never appear.
    CHECK(p.dump().find("moderatorId") == std::string::npos);

    // u2 only has an infraction; the infraction shows, the moderator does not.
    const json q = noxy::buildMemberProfile(db, "u2", 1060000);
    CHECK(q["servers"].size() == 1);
    CHECK(q["servers"][0]["infractions"][0]["type"] == "timeout");
    CHECK(q["servers"][0]["warnings"].empty());
    CHECK(q.dump().find("moderatorId") == std::string::npos);
    CHECK(q["xpNeeded"] == 1200);  // level 12

    // Unknown member: safe defaults, no rank.
    const json z = noxy::buildMemberProfile(db, "zzz", 1060000);
    CHECK(z["hasProfile"] == false);
    CHECK(z["level"] == 1);
    CHECK(z["rank"].is_null());
    CHECK(z["servers"].empty());

    // Leaderboards.
    const json lb = noxy::buildMemberLeaderboard(db, "coins", "u1");
    CHECK(lb["entries"][0]["label"] == "••••");       // ids of 2 chars are fully masked
    CHECK(lb["entries"][0]["value"] == 1000);
    CHECK(lb["entries"][1]["isYou"] == true);
    CHECK(lb["you"]["rank"] == 2);
    CHECK(lb["you"]["value"] == 150);
    CHECK(noxy::buildMemberLeaderboard(db, "level", "u1")["entries"][0]["value"] == 12);
    CHECK(noxy::buildMemberLeaderboard(db, "wins", "u1")["entries"][0]["isYou"] == true);
    CHECK(noxy::buildMemberLeaderboard(db, "bogus", "u1")["metric"] == "coins");
    CHECK(noxy::maskUserId("123456789") == "•••• 6789");
}

static void testStore(const fs::path& fixture) {
    const fs::path work = fs::temp_directory_path() / "noxy-dashboard-store-test.json";
    fs::copy_file(fixture, work, fs::copy_options::overwrite_existing);

    noxy::DatabaseStore store(work);
    auto first = store.current();
    CHECK(first != nullptr);
    CHECK(store.lastError().empty());
    if (first) CHECK(first->db["guilds"].size() == 2);

    // A broken write keeps the last good snapshot and reports the problem.
    {
        std::ofstream(work, std::ios::trunc) << "{ this is not json";
    }
    auto broken = store.current();
    CHECK(broken != nullptr);
    CHECK(broken == first);
    CHECK(!store.lastError().empty());

    // Restoring a valid file clears the error.
    fs::copy_file(fixture, work, fs::copy_options::overwrite_existing);
    auto restored = store.current();
    CHECK(restored != nullptr);
    CHECK(store.lastError().empty());

    // Missing file: no snapshot is returned after the first load fails.
    fs::remove(work);
    noxy::DatabaseStore missing(work);
    CHECK(missing.current() == nullptr);
    CHECK(!missing.lastError().empty());
}

int main(int argc, char** argv) {
    const fs::path fixtures = argc > 1 ? fs::path(argv[1]) : fs::path("tests/fixtures");
    const fs::path file = fixtures / "levidatabase.json";
    const json db = loadFixture(file);

    testSummary(db);
    testGuildDetail(db);
    testEconomy(db);
    testSerialization();
    testMember(db);
    testStore(file);

    std::cout << checks - failures << "/" << checks << " checks passed\n";
    return failures == 0 ? 0 : 1;
}
