// discord_auth.hpp
// "Log in with Discord" for members. The browser never sees the client secret or
// the Discord access token. The server keeps sessions in memory and hands the
// browser an opaque, HttpOnly cookie.
#pragma once

#include <cstddef>
#include <cstdint>
#include <map>
#include <mutex>
#include <optional>
#include <string>

namespace noxy {

struct AuthConfig {
    std::string clientId = "1551780857822314578";
    std::string clientSecret;                              // NOXY_DISCORD_CLIENT_SECRET (required for login)
    std::string publicUrl = "http://127.0.0.1:8080";       // NOXY_PUBLIC_URL, the address members open
    std::string discordWeb = "https://discord.com";        // NOXY_DISCORD_WEB (override for testing)
    std::string discordApi = "https://discord.com/api/v10";  // NOXY_DISCORD_API (override for testing)

    bool configured() const { return !clientSecret.empty(); }
    bool secureCookies() const { return publicUrl.rfind("https://", 0) == 0; }
    std::string redirectUri() const { return publicUrl + "/auth/callback"; }
};

struct MemberSession {
    std::string userId;
    std::string username;
    std::string avatar;  // Discord avatar hash, may be empty
    std::int64_t expiresMs = 0;
};

// Holds sessions in memory. They are lost when the server restarts, so members log in again.
class SessionStore {
public:
    std::string create(MemberSession session);
    std::optional<MemberSession> find(const std::string& token, std::int64_t nowMs);
    void erase(const std::string& token);

private:
    std::mutex mutex_;
    std::map<std::string, MemberSession> sessions_;
};

// Random hex string from the system random source.
std::string randomHex(std::size_t bytes);

// Percent-encodes a value for a URL query or form body.
std::string urlEncode(const std::string& value);

// Exchanges the OAuth code for the member's Discord identity.
// Returns nothing and fills error on failure.
std::optional<MemberSession> completeLogin(const AuthConfig& cfg, const std::string& code, std::int64_t nowMs,
                                           std::string& error);

}  // namespace noxy
