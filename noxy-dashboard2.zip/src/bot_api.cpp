// bot_api.cpp
#include "bot_api.hpp"

#include <httplib.h>

#include <cctype>
#include <cstdlib>

namespace noxy {

bool isSnowflake(const std::string& value) {
    if (value.size() < 15 || value.size() > 25) return false;
    for (const char c : value) {
        if (!std::isdigit(static_cast<unsigned char>(c))) return false;
    }
    return true;
}

namespace {

constexpr int kBotTimeoutSeconds = 5;

struct Target {
    std::string host;
    int port = 0;
};

// Accepts only http://127.0.0.1:<port> or http://localhost:<port>. Anything else is refused,
// because the request carries the bot's internal key.
bool parseLoopbackUrl(const std::string& url, Target& out) {
    const std::string prefix = "http://";
    if (url.rfind(prefix, 0) != 0) return false;
    std::string rest = url.substr(prefix.size());
    while (!rest.empty() && rest.back() == '/') rest.pop_back();
    const auto colon = rest.rfind(':');
    if (colon == std::string::npos) return false;
    out.host = rest.substr(0, colon);
    const std::string portText = rest.substr(colon + 1);
    if (out.host != "127.0.0.1" && out.host != "localhost") return false;
    if (portText.empty() || portText.size() > 5) return false;
    for (const char c : portText) {
        if (!std::isdigit(static_cast<unsigned char>(c))) return false;
    }
    out.port = std::atoi(portText.c_str());
    return out.port > 0 && out.port <= 65535;
}

}  // namespace

BotApiReply callBotApi(const BotApiConfig& cfg, const std::string& method, const std::string& userId,
                       const std::string& guildId, const std::string& jsonBody) {
    BotApiReply reply;
    Target target;
    if (!cfg.configured() || !isSnowflake(userId) || (!guildId.empty() && !isSnowflake(guildId)) ||
        !parseLoopbackUrl(cfg.baseUrl, target)) {
        return reply;  // status 0: the caller reports the bot as unavailable
    }

    std::string path = "/internal/users/" + userId + "/guilds";
    if (!guildId.empty()) path += "/" + guildId + "/settings";

    httplib::Headers headers{{"X-Noxy-Internal-Key", cfg.key}, {"Accept", "application/json"}};
    httplib::Client cli(target.host, target.port);
    cli.set_connection_timeout(kBotTimeoutSeconds);
    cli.set_read_timeout(kBotTimeoutSeconds);
    cli.set_write_timeout(kBotTimeoutSeconds);

    httplib::Result res;
    if (method == "PATCH") {
        res = cli.Patch(path, headers, jsonBody, "application/json");
    } else {
        res = cli.Get(path, headers);
    }
    if (!res) return reply;
    reply.status = res->status;
    reply.body = res->body;
    return reply;
}

}  // namespace noxy
