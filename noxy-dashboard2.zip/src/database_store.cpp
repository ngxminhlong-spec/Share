// database_store.cpp
#include "database_store.hpp"

#include <chrono>
#include <fstream>
#include <sstream>
#include <system_error>

namespace noxy {

std::int64_t unixTimeMs() {
    using namespace std::chrono;
    return duration_cast<milliseconds>(system_clock::now().time_since_epoch()).count();
}

namespace {

// C++17 has no clock_cast, so map a file timestamp onto the system clock by
// measuring the offset between the two clocks at the same instant.
std::int64_t fileTimeToUnixMs(std::filesystem::file_time_type t) {
    using namespace std::chrono;
    const auto fileNow = std::filesystem::file_time_type::clock::now();
    const auto sysNow = system_clock::now();
    const auto sysTime = sysNow + duration_cast<system_clock::duration>(t - fileNow);
    return duration_cast<milliseconds>(sysTime.time_since_epoch()).count();
}

}  // namespace

DatabaseStore::DatabaseStore(std::filesystem::path file) : file_(std::move(file)) {}

std::shared_ptr<const Snapshot> DatabaseStore::current() {
    std::lock_guard<std::mutex> lock(mutex_);
    reloadIfChanged();
    return snapshot_;
}

std::string DatabaseStore::lastError() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return error_;
}

void DatabaseStore::reloadIfChanged() {
    std::error_code ec;
    const auto size = std::filesystem::file_size(file_, ec);
    if (ec) {
        error_ = "Database file not found. Check the --db path.";
        return;
    }
    const auto mtime = std::filesystem::last_write_time(file_, ec);
    if (ec) {
        error_ = "Database file could not be inspected.";
        return;
    }
    const std::int64_t mtimeMs = fileTimeToUnixMs(mtime);
    const auto bytes = static_cast<std::int64_t>(size);

    if (snapshot_ && error_.empty() && mtimeMs == loadedMtimeMs_ && bytes == loadedBytes_) {
        return;  // unchanged since the last successful load
    }

    std::ifstream in(file_, std::ios::binary);
    if (!in) {
        error_ = "Database file could not be opened. Check its permissions.";
        return;
    }
    std::ostringstream buffer;
    buffer << in.rdbuf();

    json db;
    try {
        db = json::parse(buffer.str());
    } catch (const json::exception&) {
        // Keep the last good snapshot. Retry on the next request.
        error_ = "Database file is not valid JSON right now. Showing the last good copy.";
        loadedMtimeMs_ = -1;
        return;
    }
    if (!db.is_object()) {
        error_ = "Database root is not a JSON object.";
        return;
    }

    auto snap = std::make_shared<Snapshot>();
    snap->db = std::move(db);
    snap->source.fileBytes = bytes;
    snap->source.fileModifiedMs = mtimeMs;
    snapshot_ = std::move(snap);
    loadedMtimeMs_ = mtimeMs;
    loadedBytes_ = bytes;
    error_.clear();
}

}  // namespace noxy
