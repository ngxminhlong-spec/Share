// bot_api.hpp
// Client for the Noxy bot's internal settings API (src/web-api.js in the bot).
// The bot only listens on 127.0.0.1, and this client refuses any other address, so the
// shared key never leaves the machine. The bot re-checks each member's Manage Server
// permission on every call. The dashboard only forwards the member's own Discord ID.
#pragma once

#include <string>

namespace noxy {

struct BotApiConfig {
    std::string baseUrl = "http://127.0.0.1:8787";  // NOXY_BOT_API
    std::string key;                                // NOXY_INTERNAL_KEY, at least 24 characters

    bool configured() const { return key.size() >= 24; }
};

struct BotApiReply {
    int status = 0;    // HTTP status from the bot, or 0 when the bot cannot be reached
    std::string body;  // raw response body from the bot
};

// True for a Discord snowflake (15 to 25 digits). Anything else is refused before a request is made.
bool isSnowflake(const std::string& value);

// GET (guildId empty: list the servers this member can manage) or PATCH (change one server's settings).
BotApiReply callBotApi(const BotApiConfig& cfg, const std::string& method, const std::string& userId,
                       const std::string& guildId, const std::string& jsonBody);

}  // namespace noxy
