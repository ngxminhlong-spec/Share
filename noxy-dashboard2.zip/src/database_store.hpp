// database_store.hpp
// Keeps a parsed copy of levidatabase.json and reloads it when the file changes.
#pragma once

#include "stats.hpp"

#include <cstdint>
#include <filesystem>
#include <memory>
#include <mutex>
#include <string>

namespace noxy {

// Current Unix time in milliseconds.
std::int64_t unixTimeMs();

struct Snapshot {
    json db;             // the parsed database document
    SourceInfo source;   // file size and modification time at load time
};

class DatabaseStore {
public:
    explicit DatabaseStore(std::filesystem::path file);

    // Returns the newest good snapshot, reloading first if the file changed.
    // Returns null when no good snapshot has ever been loaded. The bot writes
    // through a temp file and rename, so readers normally see complete files,
    // but a failed parse keeps the previous snapshot instead of breaking the UI.
    std::shared_ptr<const Snapshot> current();

    // Empty when the last load succeeded; otherwise a short human-readable reason.
    std::string lastError() const;

    const std::filesystem::path& file() const { return file_; }

private:
    void reloadIfChanged();

    std::filesystem::path file_;
    mutable std::mutex mutex_;
    std::shared_ptr<const Snapshot> snapshot_;
    std::string error_;
    std::int64_t loadedMtimeMs_ = -1;
    std::int64_t loadedBytes_ = -1;
};

}  // namespace noxy
