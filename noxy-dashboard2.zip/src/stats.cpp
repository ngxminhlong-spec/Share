// stats.cpp
#include "stats.hpp"

#include <algorithm>
#include <cstddef>
#include <iterator>
#include <limits>
#include <map>
#include <string>
#include <utility>
#include <vector>

namespace noxy {
namespace {

const json kNull = nullptr;

// ---------- defensive accessors ----------
// The database grows over years of use, so every read tolerates missing keys,
// wrong types and legacy shapes instead of throwing.

const json& field(const json& object, const std::string& key) {
    if (!object.is_object()) return kNull;
    const auto it = object.find(key);
    return it == object.end() ? kNull : *it;
}

double asNumber(const json& v) {
    if (v.is_number()) return v.get<double>();
    if (v.is_string()) {
        try {
            return std::stod(v.get<std::string>());
        } catch (...) {
            return 0.0;
        }
    }
    return 0.0;
}

std::int64_t asInt(const json& v) { return static_cast<std::int64_t>(asNumber(v)); }

bool asBool(const json& v) { return v.is_boolean() && v.get<bool>(); }

bool isSet(const json& v) {
    if (v.is_null()) return false;
    if (v.is_string()) return !v.get_ref<const std::string&>().empty();
    return true;
}

bool isStatus(const json& v, const char* status) {
    return v.is_string() && v.get_ref<const std::string&>() == status;
}

std::int64_t countOf(const json& v) {
    return (v.is_array() || v.is_object()) ? static_cast<std::int64_t>(v.size()) : 0;
}

template <typename Fn>
void eachEntry(const json& object, Fn fn) {
    if (!object.is_object()) return;
    for (auto it = object.begin(); it != object.end(); ++it) fn(it.key(), it.value());
}

template <typename Fn>
void eachItem(const json& array, Fn fn) {
    if (!array.is_array()) return;
    for (const auto& item : array) fn(item);
}

// Cuts a string to at most maxBytes without splitting a UTF-8 sequence.
std::string clip(std::string s, std::size_t maxBytes) {
    if (s.size() <= maxBytes) return s;
    std::size_t cut = maxBytes;
    while (cut > 0 && (static_cast<unsigned char>(s[cut]) & 0xC0) == 0x80) --cut;
    s.resize(cut);
    s += "...";
    return s;
}

// Display text for a scalar value. Objects and arrays become an empty string.
std::string scalarText(const json& v, std::size_t maxBytes = 200) {
    if (v.is_string()) return clip(v.get<std::string>(), maxBytes);
    if (v.is_boolean()) return v.get<bool>() ? "true" : "false";
    if (v.is_number_integer()) return std::to_string(v.get<std::int64_t>());
    if (v.is_number()) return std::to_string(v.get<double>());
    return "";
}

// ---------- feature catalogue ----------

bool enabledFlag(const json& g, const char* key) { return asBool(field(field(g, key), "enabled")); }

struct FeatureDef {
    const char* key;
    const char* label;
    const char* category;
    bool (*isOn)(const json& guild);
};

const FeatureDef kFeatures[] = {
    {"welcome", "Welcome messages", "Community", [](const json& g) { return enabledFlag(g, "welcome"); }},
    {"goodbye", "Goodbye messages", "Community", [](const json& g) { return enabledFlag(g, "goodbye"); }},
    {"autorole", "Autorole", "Community",
     [](const json& g) { return isSet(field(g, "autoroleId")) || countOf(field(g, "autoroleIds")) > 0; }},
    {"reactionRoles", "Reaction roles", "Community",
     [](const json& g) { return countOf(field(g, "reactionRoles")) > 0; }},
    {"giveaways", "Giveaways", "Community", [](const json& g) { return countOf(field(g, "giveaways")) > 0; }},
    {"polls", "Polls", "Community", [](const json& g) { return countOf(field(g, "polls")) > 0; }},
    {"suggestions", "Suggestions", "Community",
     [](const json& g) { return isSet(field(field(g, "suggestions"), "channelId")); }},
    {"starboard", "Starboard", "Community", [](const json& g) { return enabledFlag(g, "starboard"); }},
    {"booster", "Booster rewards", "Community", [](const json& g) { return enabledFlag(g, "booster"); }},
    {"voiceMaster", "VoiceMaster", "Community", [](const json& g) { return enabledFlag(g, "voiceMaster"); }},
    {"feedback", "Feedback panel", "Community", [](const json& g) { return enabledFlag(g, "feedback"); }},
    {"tickets", "Tickets", "Support",
     [](const json& g) {
         const json& t = field(g, "ticket");
         return isSet(field(t, "categoryId")) || isSet(field(t, "panelMessageId"));
     }},
    {"verification", "Verification", "Security", [](const json& g) { return enabledFlag(g, "verification"); }},
    {"antiNuke", "Anti-nuke", "Security", [](const json& g) { return enabledFlag(g, "antiNuke"); }},
    {"automod", "AutoMod", "Moderation", [](const json& g) { return enabledFlag(g, "automod"); }},
    {"automodLogs", "AutoMod logs", "Moderation", [](const json& g) { return enabledFlag(g, "autoModLogs"); }},
    {"autoLogs", "Auto logs", "Moderation", [](const json& g) { return enabledFlag(g, "autoLogs"); }},
    {"imageOnly", "Image-only channels", "Moderation",
     [](const json& g) { return countOf(field(g, "imageOnlyChannels")) > 0; }},
    {"sticky", "Sticky messages", "Utilities",
     [](const json& g) { return countOf(field(field(g, "sticky"), "channels")) > 0; }},
    {"autoReact", "Auto-react rules", "Utilities",
     [](const json& g) { return countOf(field(field(g, "autoReact"), "rules")) > 0; }},
    {"customCommands", "Custom commands", "Utilities",
     [](const json& g) { return countOf(field(g, "customCommands")) > 0; }},
    {"inviteTracking", "Invite tracking", "Utilities",
     [](const json& g) { return countOf(field(field(g, "inviteTracking"), "records")) > 0; }},
    {"serverStats", "Server stats", "Community",
     [](const json& g) { return isSet(field(field(g, "serverStats"), "categoryId")); }},
    {"serviceOrders", "Service orders", "Utilities",
     [](const json& g) { return isSet(field(field(g, "serviceOrders"), "categoryId")); }},
};
constexpr std::size_t kFeatureCount = std::size(kFeatures);

// ---------- users ----------

struct UserRow {
    std::string id;
    std::int64_t coins = 0;
    std::int64_t bank = 0;
    std::int64_t xp = 0;
    std::int64_t level = 1;
    std::int64_t wins = 0;
    std::int64_t losses = 0;
    std::int64_t games = 0;
    std::int64_t wealth() const { return coins + bank; }
};

std::vector<UserRow> readUsers(const json& db) {
    std::vector<UserRow> rows;
    eachEntry(field(db, "users"), [&](const std::string& id, const json& u) {
        UserRow row;
        row.id = id;
        row.coins = asInt(field(u, "coins"));
        row.bank = asInt(field(u, "bank"));
        row.xp = asInt(field(u, "xp"));
        row.level = field(u, "level").is_null() ? 1 : asInt(field(u, "level"));
        const json& stats = field(u, "stats");
        row.wins = asInt(field(stats, "wins"));
        row.losses = asInt(field(stats, "losses"));
        row.games = asInt(field(stats, "games"));
        rows.push_back(std::move(row));
    });
    return rows;
}

json userJson(const UserRow& u) {
    return json{{"userId", u.id},   {"coins", u.coins}, {"bank", u.bank},  {"wealth", u.wealth()},
                {"level", u.level}, {"xp", u.xp},       {"wins", u.wins},  {"games", u.games}};
}

// ---------- guilds ----------

json guildSummary(const std::string& id, const json& g, const json& bot) {
    std::int64_t messages = 0;
    eachEntry(field(g, "messageCounts"), [&](const std::string&, const json& v) { messages += asInt(v); });

    std::int64_t warnings = 0;
    eachEntry(field(g, "warnings"), [&](const std::string&, const json& v) { warnings += countOf(v); });

    std::int64_t infractions = 0;
    eachEntry(field(g, "infractions"), [&](const std::string&, const json& v) { infractions += countOf(v); });

    std::int64_t openTickets = 0;
    std::int64_t totalTickets = 0;
    eachEntry(field(field(g, "ticket"), "tickets"), [&](const std::string&, const json& t) {
        ++totalTickets;
        // The bot deletes a ticket's record when it closes; "deleting" is the short window before that.
        if (!isStatus(field(t, "status"), "closed") && !isStatus(field(t, "status"), "deleting")) ++openTickets;
    });

    std::int64_t activeGiveaways = 0;
    eachEntry(field(g, "giveaways"), [&](const std::string&, const json& gw) {
        if (!asBool(field(gw, "finished"))) ++activeGiveaways;
    });

    std::int64_t features = 0;
    for (const auto& f : kFeatures) {
        if (f.isOn(g)) ++features;
    }

    return json{
        {"id", id},
        {"messages", messages},
        {"commands", asInt(field(field(bot, "serverCommandUsage"), id))},
        {"warnings", warnings},
        {"infractions", infractions},
        {"openTickets", openTickets},
        {"totalTickets", totalTickets},
        {"activeGiveaways", activeGiveaways},
        {"starred", countOf(field(field(g, "starboard"), "starred"))},
        {"customCommands", countOf(field(g, "customCommands"))},
        {"features", features},
        {"featureTotal", kFeatureCount},
        {"antiNuke", enabledFlag(g, "antiNuke")},
        {"automod", enabledFlag(g, "automod")},
        {"welcome", enabledFlag(g, "welcome")},
        {"logChannel", isSet(field(g, "logChannelId"))},
    };
}

bool moreActive(const json& a, const json& b) {
    const auto am = a.at("messages").get<std::int64_t>();
    const auto bm = b.at("messages").get<std::int64_t>();
    if (am != bm) return am > bm;
    const auto ac = a.at("commands").get<std::int64_t>();
    const auto bc = b.at("commands").get<std::int64_t>();
    if (ac != bc) return ac > bc;
    return a.at("id").get<std::string>() < b.at("id").get<std::string>();
}

// Sorted (command name, count) pairs from the bot's global counter.
std::vector<std::pair<std::string, std::int64_t>> commandCounts(const json& bot) {
    std::vector<std::pair<std::string, std::int64_t>> out;
    eachEntry(field(bot, "commandUsage"), [&](const std::string& name, const json& v) {
        const std::int64_t count = asInt(v);
        if (count > 0) out.emplace_back(name, count);
    });
    std::sort(out.begin(), out.end(), [](const auto& a, const auto& b) {
        return a.second != b.second ? a.second > b.second : a.first < b.first;
    });
    return out;
}

}  // namespace

// ==================== public API ====================

std::string dumpJson(const json& value) {
    return value.dump(-1, ' ', false, json::error_handler_t::replace);
}

json buildGuildList(const json& db) {
    const json& bot = field(db, "bot");
    std::vector<json> items;
    eachEntry(field(db, "guilds"), [&](const std::string& id, const json& g) {
        items.push_back(guildSummary(id, g, bot));
    });
    std::sort(items.begin(), items.end(), moreActive);
    return json(items);
}

json buildPublicOverview(const json& db) {
    const json guilds = buildGuildList(db);
    std::int64_t messages = 0;
    for (const auto& g : guilds) messages += g.at("messages").get<std::int64_t>();

    std::int64_t commands = 0;
    for (const auto& entry : commandCounts(field(db, "bot"))) commands += entry.second;

    return {{"servers", guilds.size()},
            {"members", readUsers(db).size()},
            {"messages", messages},
            {"commands", commands}};
}

json buildSummary(const json& db, const SourceInfo& source) {
    const json& bot = field(db, "bot");
    const json guilds = buildGuildList(db);

    std::int64_t messages = 0, commands = 0, warnings = 0, infractions = 0;
    std::int64_t openTickets = 0, activeGiveaways = 0;
    std::vector<std::int64_t> featureHits(kFeatureCount, 0);
    eachEntry(field(db, "guilds"), [&](const std::string&, const json& g) {
        for (std::size_t i = 0; i < kFeatureCount; ++i) {
            if (kFeatures[i].isOn(g)) ++featureHits[i];
        }
    });
    for (const auto& g : guilds) {
        messages += g.at("messages").get<std::int64_t>();
        commands += g.at("commands").get<std::int64_t>();
        warnings += g.at("warnings").get<std::int64_t>();
        infractions += g.at("infractions").get<std::int64_t>();
        openTickets += g.at("openTickets").get<std::int64_t>();
        activeGiveaways += g.at("activeGiveaways").get<std::int64_t>();
    }

    const auto users = readUsers(db);
    std::int64_t coins = 0, bank = 0, xp = 0, games = 0, wins = 0, losses = 0;
    for (const auto& u : users) {
        coins += u.coins;
        bank += u.bank;
        xp += u.xp;
        games += u.games;
        wins += u.wins;
        losses += u.losses;
    }

    const auto counts = commandCounts(bot);
    std::int64_t commandTotal = 0;
    json topCommands = json::array();
    for (std::size_t i = 0; i < counts.size(); ++i) {
        commandTotal += counts[i].second;
        if (i < 12) topCommands.push_back({{"name", counts[i].first}, {"count", counts[i].second}});
    }

    const std::size_t guildCount = guilds.size();
    json features = json::array();
    for (std::size_t i = 0; i < kFeatureCount; ++i) {
        const double percent = guildCount ? 100.0 * static_cast<double>(featureHits[i]) / static_cast<double>(guildCount) : 0.0;
        features.push_back({{"key", kFeatures[i].key},
                            {"label", kFeatures[i].label},
                            {"category", kFeatures[i].category},
                            {"guilds", featureHits[i]},
                            {"percent", percent}});
    }

    json topGuilds = json::array();
    for (std::size_t i = 0; i < guilds.size() && i < 5; ++i) topGuilds.push_back(guilds[i]);

    // Servers with the most warnings and infractions, for the moderation card.
    std::vector<json> moderated;
    for (const auto& g : guilds) {
        if (g.at("warnings").get<std::int64_t>() + g.at("infractions").get<std::int64_t>() > 0) moderated.push_back(g);
    }
    std::sort(moderated.begin(), moderated.end(), [](const json& a, const json& b) {
        const auto ac = a.at("warnings").get<std::int64_t>() + a.at("infractions").get<std::int64_t>();
        const auto bc = b.at("warnings").get<std::int64_t>() + b.at("infractions").get<std::int64_t>();
        return ac != bc ? ac > bc : a.at("id").get<std::string>() < b.at("id").get<std::string>();
    });
    json topModerated = json::array();
    for (std::size_t i = 0; i < moderated.size() && i < 5; ++i) {
        topModerated.push_back({{"id", moderated[i].at("id")},
                                {"warnings", moderated[i].at("warnings")},
                                {"infractions", moderated[i].at("infractions")}});
    }

    const std::int64_t startedAt = asInt(field(bot, "startedAt"));
    const json support = field(bot, "support");

    return json{
        {"generatedAt", source.nowMs},
        {"database",
         {{"bytes", source.fileBytes},
          {"modifiedAt", source.fileModifiedMs},
          {"ageMs", std::max<std::int64_t>(0, source.nowMs - source.fileModifiedMs)},
          {"guildCount", guildCount},
          {"userCount", users.size()}}},
        // bot.startedAt is written once, when the database is created. It is not
        // a process start time, so it is reported as "tracking since".
        {"bot",
         {{"trackingSince", startedAt},
          {"trackingMs", startedAt > 0 && source.nowMs > startedAt ? source.nowMs - startedAt : 0},
          {"uniqueCommands", counts.size()},
          {"noPrefixUsers", countOf(field(bot, "noPrefixUsers"))},
          {"supportConfigured", isSet(field(support, "guildId"))}}},
        {"totals",
         {{"guilds", guildCount},
          {"users", users.size()},
          {"messages", messages},
          {"commands", commandTotal},
          {"commandsByServer", commands},
          {"warnings", warnings},
          {"infractions", infractions},
          {"openTickets", openTickets},
          {"activeGiveaways", activeGiveaways},
          {"coins", coins},
          {"bank", bank},
          {"wealth", coins + bank},
          {"xp", xp},
          {"games", games},
          {"wins", wins},
          {"losses", losses}}},
        {"topCommands", topCommands},
        {"features", features},
        {"topGuilds", topGuilds},
        {"topModerated", topModerated},
    };
}

json buildEconomy(const json& db) {
    auto users = readUsers(db);

    std::int64_t coins = 0, bank = 0, xp = 0, games = 0, wins = 0, losses = 0, levelSum = 0;
    for (const auto& u : users) {
        coins += u.coins;
        bank += u.bank;
        xp += u.xp;
        games += u.games;
        wins += u.wins;
        losses += u.losses;
        levelSum += u.level;
    }
    const double averageLevel = users.empty() ? 0.0 : static_cast<double>(levelSum) / static_cast<double>(users.size());
    const double winRate = games > 0 ? 100.0 * static_cast<double>(wins) / static_cast<double>(games) : 0.0;

    std::sort(users.begin(), users.end(), [](const UserRow& a, const UserRow& b) {
        return a.wealth() != b.wealth() ? a.wealth() > b.wealth() : a.id < b.id;
    });
    json leaderboard = json::array();
    for (std::size_t i = 0; i < users.size() && i < 25; ++i) leaderboard.push_back(userJson(users[i]));

    // Level spread, using the same buckets everywhere.
    struct Bucket { const char* label; std::int64_t min; std::int64_t max; std::int64_t count; };
    Bucket buckets[] = {{"1", 1, 1, 0},       {"2–5", 2, 5, 0},     {"6–10", 6, 10, 0},
                        {"11–20", 11, 20, 0}, {"21–50", 21, 50, 0},
                        {"51+", 51, std::numeric_limits<std::int64_t>::max(), 0}};
    for (const auto& u : users) {
        for (auto& b : buckets) {
            if (u.level >= b.min && u.level <= b.max) {
                ++b.count;
                break;
            }
        }
    }
    json levels = json::array();
    for (const auto& b : buckets) levels.push_back({{"label", b.label}, {"count", b.count}});

    // Inventory: each user's inventory is a list of [itemName, quantity] pairs.
    std::map<std::string, std::pair<std::int64_t, std::int64_t>> items;  // name -> (total, holders)
    eachEntry(field(db, "users"), [&](const std::string&, const json& user) {
        std::map<std::string, bool> seen;
        eachItem(field(user, "inventory"), [&](const json& entry) {
            if (!entry.is_array() || entry.size() < 1 || !entry[0].is_string()) return;
            const std::string name = clip(entry[0].get<std::string>(), 80);
            const std::int64_t qty = entry.size() > 1 ? asInt(entry[1]) : 1;
            if (qty <= 0) return;
            auto& slot = items[name];
            slot.first += qty;
            if (!seen[name]) {
                seen[name] = true;
                ++slot.second;
            }
        });
    });
    std::vector<std::pair<std::string, std::pair<std::int64_t, std::int64_t>>> sortedItems(items.begin(), items.end());
    std::sort(sortedItems.begin(), sortedItems.end(), [](const auto& a, const auto& b) {
        return a.second.first != b.second.first ? a.second.first > b.second.first : a.first < b.first;
    });
    json inventory = json::array();
    for (std::size_t i = 0; i < sortedItems.size() && i < 15; ++i) {
        inventory.push_back({{"name", sortedItems[i].first},
                             {"total", sortedItems[i].second.first},
                             {"holders", sortedItems[i].second.second}});
    }

    return json{
        {"totals",
         {{"users", users.size()},
          {"coins", coins},
          {"bank", bank},
          {"wealth", coins + bank},
          {"xp", xp},
          {"games", games},
          {"wins", wins},
          {"losses", losses},
          {"winRate", winRate},
          {"averageLevel", averageLevel}}},
        {"leaderboard", leaderboard},
        {"levels", levels},
        {"inventory", inventory},
    };
}

json buildGuildDetail(const json& db, const std::string& guildId, std::int64_t nowMs) {
    const json& guilds = field(db, "guilds");
    if (!guilds.is_object() || !guilds.contains(guildId)) return nullptr;
    const json& g = guilds.at(guildId);
    const json& bot = field(db, "bot");
    (void)nowMs;

    json features = json::array();
    for (const auto& f : kFeatures) {
        features.push_back({{"key", f.key}, {"label", f.label}, {"category", f.category}, {"enabled", f.isOn(g)}});
    }

    // Top chatters from the all-time message counter.
    std::vector<std::pair<std::string, std::int64_t>> chatters;
    eachEntry(field(g, "messageCounts"), [&](const std::string& user, const json& v) {
        chatters.emplace_back(user, asInt(v));
    });
    std::sort(chatters.begin(), chatters.end(), [](const auto& a, const auto& b) {
        return a.second != b.second ? a.second > b.second : a.first < b.first;
    });
    json topChatters = json::array();
    for (std::size_t i = 0; i < chatters.size() && i < 10; ++i) {
        topChatters.push_back({{"userId", chatters[i].first}, {"messages", chatters[i].second}});
    }

    // Warnings and infractions are stored per user as lists; flatten and sort by time.
    json warnings = json::array();
    eachEntry(field(g, "warnings"), [&](const std::string& user, const json& list) {
        eachItem(list, [&](const json& w) {
            warnings.push_back({{"userId", user},
                                {"reason", scalarText(field(w, "reason"))},
                                {"moderatorId", scalarText(field(w, "moderatorId"))},
                                {"at", asInt(field(w, "at"))}});
        });
    });
    json infractions = json::array();
    eachEntry(field(g, "infractions"), [&](const std::string& user, const json& list) {
        eachItem(list, [&](const json& w) {
            infractions.push_back({{"userId", user},
                                   {"type", scalarText(field(w, "type"), 60)},
                                   {"reason", scalarText(field(w, "reason"))},
                                   {"moderatorId", scalarText(field(w, "moderatorId"))},
                                   {"at", asInt(field(w, "at"))}});
        });
    });
    auto newestFirst = [](json& list, std::size_t cap) {
        std::sort(list.begin(), list.end(), [](const json& a, const json& b) {
            return a.at("at").get<std::int64_t>() > b.at("at").get<std::int64_t>();
        });
        if (list.size() > cap) list.erase(list.begin() + static_cast<std::ptrdiff_t>(cap), list.end());
    };
    newestFirst(warnings, 12);
    newestFirst(infractions, 12);

    // Ticket records have no timestamp. Discord channel IDs grow over time, so sort by ID instead.
    json tickets = json::array();
    eachEntry(field(field(g, "ticket"), "tickets"), [&](const std::string& channel, const json& t) {
        tickets.push_back({{"channelId", channel},
                           {"status", scalarText(field(t, "status"), 40)},
                           {"ownerId", scalarText(field(t, "ownerId"), 25)},
                           {"claimed", isSet(field(t, "claimedBy"))}});
    });
    std::sort(tickets.begin(), tickets.end(), [](const json& a, const json& b) {
        const std::string& x = a.at("channelId").get_ref<const std::string&>();
        const std::string& y = b.at("channelId").get_ref<const std::string&>();
        return x.size() != y.size() ? x.size() > y.size() : x > y;
    });
    if (tickets.size() > 10) tickets.erase(tickets.begin() + 10, tickets.end());

    json giveaways = json::array();
    eachEntry(field(g, "giveaways"), [&](const std::string& message, const json& gw) {
        giveaways.push_back({{"messageId", message},
                             {"prize", scalarText(field(gw, "prize"), 120)},
                             {"endsAt", asInt(field(gw, "ends"))},
                             {"finished", asBool(field(gw, "finished"))}});
    });
    std::sort(giveaways.begin(), giveaways.end(), [](const json& a, const json& b) {
        return a.at("endsAt").get<std::int64_t>() > b.at("endsAt").get<std::int64_t>();
    });
    if (giveaways.size() > 10) giveaways.erase(giveaways.begin() + 10, giveaways.end());

    // Anti-nuke: show the most recent events with their scalar fields only.
    const json& antiNuke = field(g, "antiNuke");
    json recentEvents = json::array();
    const json& history = field(antiNuke, "history").is_array() ? field(antiNuke, "history") : field(antiNuke, "recoveryHistory");
    if (history.is_array()) {
        for (std::size_t i = history.size(); i-- > 0 && recentEvents.size() < 8;) {
            const json& event = history[i];
            if (!event.is_object()) continue;
            json fields = json::array();
            for (auto it = event.begin(); it != event.end() && fields.size() < 8; ++it) {
                if (it.value().is_object() || it.value().is_array()) continue;
                fields.push_back({{"key", it.key()}, {"value", scalarText(it.value(), 120)}});
            }
            recentEvents.push_back({{"fields", fields}});
        }
    }

    const json& automod = field(g, "automod");
    json customNames = json::array();
    eachEntry(field(g, "customCommands"), [&](const std::string& name, const json&) {
        if (customNames.size() < 60) customNames.push_back(name);
    });

    return json{
        {"summary", guildSummary(guildId, g, bot)},
        {"features", features},
        {"topChatters", topChatters},
        {"warnings", warnings},
        {"infractions", infractions},
        {"tickets", tickets},
        {"giveaways", giveaways},
        {"antiNuke",
         {{"enabled", enabledFlag(g, "antiNuke")},
          {"action", scalarText(field(antiNuke, "action"), 40)},
          {"botAction", scalarText(field(antiNuke, "botAction"), 40)},
          {"windowSeconds", asInt(field(antiNuke, "detectionWindowMs")) / 1000},
          {"events", countOf(history)},
          {"recent", recentEvents}}},
        {"automod",
         {{"enabled", asBool(field(automod, "enabled"))},
          {"links", asBool(field(automod, "links"))},
          {"invites", asBool(field(automod, "invites"))},
          {"caps", asBool(field(automod, "caps"))},
          {"mentionLimit", asInt(field(automod, "mentions"))},
          {"spamLimit", asInt(field(automod, "spamLimit"))},
          {"spamWindowSeconds", asInt(field(automod, "spamWindow"))},
          {"badwords", countOf(field(automod, "badwords"))},
          {"punishment", scalarText(field(automod, "punishment"), 40)},
          {"timeoutSeconds", asInt(field(automod, "timeoutDurationMs")) / 1000}}},
        {"starboard",
         {{"enabled", enabledFlag(g, "starboard")},
          {"threshold", asInt(field(field(g, "starboard"), "threshold"))},
          {"starred", countOf(field(field(g, "starboard"), "starred"))}}},
        {"customCommands", customNames},
    };
}

// ==================== member view ====================
// Everything below is about one signed-in member, or a masked leaderboard.
// Nothing here returns another member's warnings or moderator IDs.

std::string maskUserId(const std::string& id) {
    if (id.size() <= 4) return "••••";
    return "•••• " + id.substr(id.size() - 4);
}

json buildMemberProfile(const json& db, const std::string& userId, std::int64_t nowMs) {
    const json& u = field(field(db, "users"), userId);
    const bool hasProfile = u.is_object();

    const std::int64_t level = hasProfile && !field(u, "level").is_null() ? std::max<std::int64_t>(1, asInt(field(u, "level"))) : 1;
    const std::int64_t xp = asInt(field(u, "xp"));
    const std::int64_t xpNeeded = level * 100;  // the bot levels up when xp >= level * 100
    const std::int64_t coins = asInt(field(u, "coins"));
    const std::int64_t bank = asInt(field(u, "bank"));
    const json& stats = field(u, "stats");
    const std::int64_t wins = asInt(field(stats, "wins"));
    const std::int64_t losses = asInt(field(stats, "losses"));
    const std::int64_t games = asInt(field(stats, "games"));

    json inventory = json::array();
    eachItem(field(u, "inventory"), [&](const json& entry) {
        if (!entry.is_array() || entry.empty() || !entry[0].is_string()) return;
        const std::int64_t qty = entry.size() > 1 ? asInt(entry[1]) : 1;
        if (qty > 0) inventory.push_back({{"name", clip(entry[0].get<std::string>(), 80)}, {"qty", qty}});
    });

    // Cooldowns, using the same periods as the bot's economy commands.
    auto cooldown = [&](const char* key, std::int64_t periodMs) {
        const std::int64_t last = asInt(field(u, key));
        const std::int64_t readyAt = last + periodMs;
        return json{{"readyAt", readyAt}, {"ready", nowMs >= readyAt}};
    };
    json cooldowns = {{"daily", cooldown("daily", 86400000)},
                      {"work", cooldown("work", 3600000)},
                      {"rob", cooldown("rob", 3600000)},
                      {"fish", cooldown("fish", 300000)},
                      {"hunt", cooldown("hunt", 300000)},
                      {"crime", cooldown("crime", 600000)}};

    // Rank by wealth among everyone with a profile.
    json rank = nullptr;
    std::size_t total = 0;
    if (hasProfile) {
        const auto rows = readUsers(db);
        total = rows.size();
        std::int64_t myWealth = coins + bank;
        std::int64_t ahead = 0;
        for (const auto& r : rows) {
            if (r.wealth() > myWealth) ++ahead;
        }
        rank = ahead + 1;
    }

    // Activity per server, limited to this member's own entries.
    std::vector<json> servers;
    eachEntry(field(db, "guilds"), [&](const std::string& gid, const json& g) {
        const std::int64_t messages = asInt(field(field(g, "messageCounts"), userId));
        std::vector<json> warnings;
        eachItem(field(field(g, "warnings"), userId), [&](const json& w) {
            warnings.push_back({{"reason", scalarText(field(w, "reason"))}, {"at", asInt(field(w, "at"))}});
        });
        std::vector<json> infractions;
        eachItem(field(field(g, "infractions"), userId), [&](const json& w) {
            infractions.push_back({{"type", scalarText(field(w, "type"), 60)},
                                   {"reason", scalarText(field(w, "reason"))},
                                   {"at", asInt(field(w, "at"))}});
        });
        if (messages == 0 && warnings.empty() && infractions.empty()) return;
        auto newest = [](const json& a, const json& b) { return a.at("at").get<std::int64_t>() > b.at("at").get<std::int64_t>(); };
        std::sort(warnings.begin(), warnings.end(), newest);
        std::sort(infractions.begin(), infractions.end(), newest);
        servers.push_back({{"id", gid},
                           {"messages", messages},
                           {"warnings", json(warnings)},
                           {"infractions", json(infractions)}});
    });
    std::sort(servers.begin(), servers.end(), [](const json& a, const json& b) {
        return a.at("messages").get<std::int64_t>() > b.at("messages").get<std::int64_t>();
    });

    return json{
        {"userId", userId},
        {"hasProfile", hasProfile},
        {"level", level},
        {"xp", xp},
        {"xpNeeded", xpNeeded},
        {"coins", coins},
        {"bank", bank},
        {"wealth", coins + bank},
        {"stats", {{"wins", wins}, {"losses", losses}, {"games", games}, {"winRate", games > 0 ? 100.0 * static_cast<double>(wins) / static_cast<double>(games) : 0.0}}},
        {"inventory", inventory},
        {"cooldowns", cooldowns},
        {"rank", rank},
        {"rankTotal", total},
        {"servers", json(servers)},
    };
}

json buildMemberLeaderboard(const json& db, const std::string& metricIn, const std::string& viewerId) {
    const std::string metric = (metricIn == "level" || metricIn == "wins") ? metricIn : "coins";
    auto rows = readUsers(db);
    auto valueOf = [&](const UserRow& r) {
        if (metric == "level") return r.level;
        if (metric == "wins") return r.wins;
        return r.wealth();
    };
    std::sort(rows.begin(), rows.end(), [&](const UserRow& a, const UserRow& b) {
        return valueOf(a) != valueOf(b) ? valueOf(a) > valueOf(b) : a.id < b.id;
    });

    json entries = json::array();
    json you = nullptr;
    for (std::size_t i = 0; i < rows.size(); ++i) {
        const bool isYou = rows[i].id == viewerId;
        if (i < 10) {
            entries.push_back({{"rank", i + 1}, {"label", maskUserId(rows[i].id)}, {"value", valueOf(rows[i])}, {"isYou", isYou}});
        }
        if (isYou) you = json{{"rank", i + 1}, {"value", valueOf(rows[i])}};
    }
    return json{{"metric", metric}, {"entries", entries}, {"you", you}, {"total", rows.size()}};
}

}  // namespace noxy
