// stats.hpp
// Pure functions that turn the Noxy database document into dashboard views.
// Nothing in here touches the filesystem or the network, so it is easy to test.
#pragma once

#include <nlohmann/json.hpp>

#include <cstdint>
#include <string>

namespace noxy {

using json = nlohmann::json;

struct SourceInfo {
    std::int64_t fileBytes = 0;       // size of levidatabase.json
    std::int64_t fileModifiedMs = 0;  // last write time, ms since epoch
    std::int64_t nowMs = 0;           // server clock when the snapshot was built
};

// Home page: totals, top commands, feature adoption and the busiest servers.
json buildSummary(const json& db, const SourceInfo& source);

// Public, aggregate-only numbers for the bot overview page. No member or moderation details.
json buildPublicOverview(const json& db);

// Every server, sorted by message activity (most active first).
json buildGuildList(const json& db);

// One server in depth. Returns null when the guild is not in the database.
json buildGuildDetail(const json& db, const std::string& guildId, std::int64_t nowMs);

// Economy: totals, wealth leaderboard, level spread and popular inventory items.
json buildEconomy(const json& db);

// Member view: one member's own profile, economy, cooldowns and server activity.
// Never includes other members' warnings or moderator IDs.
json buildMemberProfile(const json& db, const std::string& userId, std::int64_t nowMs);

// Top 10 for a metric ("coins", "level" or "wins"). Other members are shown as masked IDs.
json buildMemberLeaderboard(const json& db, const std::string& metric, const std::string& viewerId);

// Shortens a Discord ID for display, e.g. "•••• 4521".
std::string maskUserId(const std::string& id);

// Serializes JSON for an HTTP response. Invalid UTF-8 is replaced instead of throwing.
std::string dumpJson(const json& value);

}  // namespace noxy
