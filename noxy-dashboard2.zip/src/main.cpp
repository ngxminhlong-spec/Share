// main.cpp
// Noxy Dashboard server.
//
//   /              member dashboard (log in with Discord, see your own stats)
//   /admin/        staff dashboard (token protected, sees every server)
//   /api/member/*  member data for the signed-in user only
//   /api/*         staff API (token protected)
//
// The server never writes to levidatabase.json, so it cannot disturb the bot.
#include "bot_api.hpp"
#include "database_store.hpp"
#include "discord_auth.hpp"
#include "stats.hpp"

#include <httplib.h>

#include <cstdlib>
#include <filesystem>
#include <functional>
#include <iostream>
#include <string>
#include <vector>

namespace fs = std::filesystem;

namespace {

constexpr int kSessionCookieSeconds = 7 * 24 * 60 * 60;

struct Options {
    fs::path db = "levidatabase.json";
    fs::path web;
    std::string host = "127.0.0.1";
    int port = 8080;
    std::string adminToken;  // NOXY_DASHBOARD_TOKEN, never taken on the command line
    noxy::AuthConfig auth;
    noxy::BotApiConfig bot;  // NOXY_BOT_API and NOXY_INTERNAL_KEY, for member server settings
};

void printUsage() {
    std::cout << "Usage: noxy-dashboard [options]\n"
                 "  --db <file>     Path to levidatabase.json (env: NOXY_DB)\n"
                 "  --web <dir>     Folder containing member/ and admin/ (default: web/ next to the binary)\n"
                 "  --host <addr>   Address to listen on (default 127.0.0.1)\n"
                 "  --port <n>      Port to listen on (default 8080)\n"
                 "\n"
                 "Environment:\n"
                 "  NOXY_DASHBOARD_TOKEN         token for /admin and /api (staff)\n"
                 "  NOXY_DISCORD_CLIENT_SECRET   Discord app secret, required for member login\n"
                 "  NOXY_PUBLIC_URL              address members open, e.g. https://noxy.example.com\n"
                 "  NOXY_DISCORD_CLIENT_ID       defaults to the Noxy bot's client ID\n"
                 "  NOXY_INTERNAL_KEY            same key as the bot's, enables member server settings\n"
                 "  NOXY_BOT_API                 bot's internal API, default http://127.0.0.1:8787\n";
}

// The UI folder is the one that contains member/index.html.
fs::path findWebDir(const char* argv0) {
    std::error_code ec;
    std::vector<fs::path> candidates;
    const fs::path exeDir = fs::absolute(argv0, ec).parent_path();
    candidates.push_back(exeDir / "web");
    candidates.push_back(exeDir / ".." / "web");
    candidates.push_back(fs::current_path(ec) / "web");
    for (const auto& dir : candidates) {
        if (fs::exists(dir / "member" / "index.html", ec)) return fs::weakly_canonical(dir, ec);
    }
    return candidates.front();
}

std::string envOr(const char* name, const std::string& fallback) {
    const char* v = std::getenv(name);
    return v && *v ? std::string(v) : fallback;
}

std::string trim(std::string s) {
    const auto first = s.find_first_not_of(" \t\r\n");
    if (first == std::string::npos) return "";
    const auto last = s.find_last_not_of(" \t\r\n");
    return s.substr(first, last - first + 1);
}

bool parseArgs(int argc, char** argv, Options& opt, bool& showHelp) {
    opt.db = envOr("NOXY_DB", opt.db.string());
    opt.adminToken = trim(envOr("NOXY_DASHBOARD_TOKEN", ""));
    opt.auth.clientId = envOr("NOXY_DISCORD_CLIENT_ID", opt.auth.clientId);
    opt.auth.clientSecret = trim(envOr("NOXY_DISCORD_CLIENT_SECRET", ""));
    opt.auth.publicUrl = envOr("NOXY_PUBLIC_URL", opt.auth.publicUrl);
    opt.auth.discordWeb = envOr("NOXY_DISCORD_WEB", opt.auth.discordWeb);
    opt.auth.discordApi = envOr("NOXY_DISCORD_API", opt.auth.discordApi);
    while (!opt.auth.publicUrl.empty() && opt.auth.publicUrl.back() == '/') opt.auth.publicUrl.pop_back();
    opt.bot.baseUrl = envOr("NOXY_BOT_API", opt.bot.baseUrl);
    opt.bot.key = trim(envOr("NOXY_INTERNAL_KEY", ""));

    for (int i = 1; i < argc; ++i) {
        const std::string arg = argv[i];
        auto next = [&](std::string& out) {
            if (i + 1 >= argc) {
                std::cerr << "Missing value for " << arg << "\n";
                return false;
            }
            out = argv[++i];
            return true;
        };
        std::string value;
        if (arg == "-h" || arg == "--help") {
            showHelp = true;
            return true;
        } else if (arg == "--db") {
            if (!next(value)) return false;
            opt.db = value;
        } else if (arg == "--web") {
            if (!next(value)) return false;
            opt.web = value;
        } else if (arg == "--host") {
            if (!next(opt.host)) return false;
        } else if (arg == "--port") {
            if (!next(value)) return false;
            try {
                opt.port = std::stoi(value);
            } catch (...) {
                opt.port = 0;
            }
            if (opt.port <= 0 || opt.port > 65535) {
                std::cerr << "Port must be between 1 and 65535.\n";
                return false;
            }
        } else {
            std::cerr << "Unknown option: " << arg << "\n";
            return false;
        }
    }
    return true;
}

// Compares secrets without stopping at the first mismatch.
bool sameSecret(const std::string& a, const std::string& b) {
    if (a.size() != b.size()) return false;
    unsigned char diff = 0;
    for (std::size_t i = 0; i < a.size(); ++i) diff |= static_cast<unsigned char>(a[i] ^ b[i]);
    return diff == 0;
}

bool isLoopback(const std::string& host) {
    return host == "127.0.0.1" || host == "localhost" || host == "::1";
}

void sendJson(httplib::Response& res, int status, const noxy::json& body) {
    res.status = status;
    res.set_content(noxy::dumpJson(body), "application/json; charset=utf-8");
}

// Reads one cookie value from the Cookie header.
std::string cookieValue(const httplib::Request& req, const std::string& name) {
    const std::string header = req.get_header_value("Cookie");
    std::size_t pos = 0;
    while (pos < header.size()) {
        std::size_t end = header.find(';', pos);
        if (end == std::string::npos) end = header.size();
        const std::string part = trim(header.substr(pos, end - pos));
        const auto eq = part.find('=');
        if (eq != std::string::npos && part.substr(0, eq) == name) return part.substr(eq + 1);
        pos = end + 1;
    }
    return "";
}

std::string makeCookie(const std::string& name, const std::string& value, int maxAgeSeconds, bool secure,
                       const std::string& path) {
    std::string c = name + "=" + value + "; Path=" + path + "; Max-Age=" + std::to_string(maxAgeSeconds) +
                    "; HttpOnly; SameSite=Lax";
    if (secure) c += "; Secure";
    return c;
}

// Discord avatar URL, or the default avatar when the member has none.
std::string avatarUrl(const std::string& userId, const std::string& hash) {
    if (!hash.empty()) {
        return "https://cdn.discordapp.com/avatars/" + userId + "/" + hash + ".png?size=256";
    }
    unsigned long long id = 0;
    try {
        id = std::stoull(userId);
    } catch (...) {
        id = 0;
    }
    return "https://cdn.discordapp.com/embed/avatars/" + std::to_string((id >> 22) % 6) + ".png";
}

}  // namespace

int main(int argc, char** argv) {
    Options opt;
    bool showHelp = false;
    if (!parseArgs(argc, argv, opt, showHelp)) {
        printUsage();
        return 2;
    }
    if (showHelp) {
        printUsage();
        return 0;
    }
    if (opt.web.empty()) opt.web = findWebDir(argv[0]);
    if (!fs::exists(opt.web / "member" / "index.html") || !fs::exists(opt.web / "admin" / "index.html")) {
        std::cerr << "UI folder not found. Expected member/index.html and admin/index.html in "
                  << opt.web.string() << ". Pass --web <dir>.\n";
        return 1;
    }

    noxy::DatabaseStore store(opt.db);
    noxy::SessionStore sessions;
    // Staff access is never open. Without NOXY_DASHBOARD_TOKEN, a random token is made for this run
    // and printed once, so an unconfigured install cannot be read by whoever finds the port.
    const bool generatedToken = opt.adminToken.empty();
    if (generatedToken) opt.adminToken = noxy::randomHex(16);
    const bool needsAdminToken = true;
    const bool secureCookies = opt.auth.secureCookies();

    // Staff API: checks X-Dashboard-Token or a Bearer header against the staff token.
    auto staffAuthorized = [&opt](const httplib::Request& req) {
        std::string provided = req.get_header_value("X-Dashboard-Token");
        if (provided.empty()) {
            const std::string auth = req.get_header_value("Authorization");
            if (auth.rfind("Bearer ", 0) == 0) provided = auth.substr(7);
        }
        return sameSecret(provided, opt.adminToken);
    };

    // Member API: the signed-in member, or nothing.
    auto currentMember = [&](const httplib::Request& req) -> std::optional<noxy::MemberSession> {
        const std::string token = cookieValue(req, "noxy_session");
        if (token.empty()) return std::nullopt;
        return sessions.find(token, noxy::unixTimeMs());
    };

    // Wraps a staff API handler: checks the token, loads the snapshot, returns 404 for null results.
    using Body = std::function<noxy::json(const noxy::Snapshot&, const httplib::Request&, bool& found)>;
    auto staffApi = [&](Body body) {
        return [&, body](const httplib::Request& req, httplib::Response& res) {
            if (!staffAuthorized(req)) {
                sendJson(res, 401, {{"error", "A valid dashboard token is required."}});
                return;
            }
            const auto snap = store.current();
            if (!snap) {
                sendJson(res, 503, {{"error", store.lastError()}});
                return;
            }
            bool found = true;
            noxy::json result = body(*snap, req, found);
            if (!found) {
                sendJson(res, 404, {{"error", "Not found."}});
                return;
            }
            sendJson(res, 200, result);
        };
    };

    httplib::Server svr;
    svr.set_default_headers({{"X-Content-Type-Options", "nosniff"},
                             {"X-Frame-Options", "DENY"},
                             {"Referrer-Policy", "same-origin"},
                             {"Cache-Control", "no-store"},
                             {"Content-Security-Policy",
                              "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
                              "img-src 'self' data: https://cdn.discordapp.com; connect-src 'self'; "
                              "frame-ancestors 'none'; base-uri 'self'; form-action 'self'"}});

    // ---------- public ----------

    svr.Get("/api/health", [&](const httplib::Request&, httplib::Response& res) {
        const auto snap = store.current();
        noxy::json body{{"ok", snap != nullptr && store.lastError().empty()},
                        {"error", store.lastError()},
                        {"database", store.file().filename().string()},
                        {"authRequired", needsAdminToken},
                        {"memberLogin", opt.auth.configured()},
                        {"serverTime", noxy::unixTimeMs()}};
        sendJson(res, snap ? 200 : 503, body);
    });

    svr.Get("/api/public/overview", [&](const httplib::Request&, httplib::Response& res) {
        const auto snap = store.current();
        if (!snap) {
            sendJson(res, 503, {{"error", "Stats are unavailable right now."}});
            return;
        }
        sendJson(res, 200, noxy::buildPublicOverview(snap->db));
    });

    // ---------- member login (Discord OAuth2) ----------

    svr.Get("/auth/login", [&](const httplib::Request&, httplib::Response& res) {
        if (!opt.auth.configured()) {
            res.status = 503;
            res.set_content("Member login is not configured. Set NOXY_DISCORD_CLIENT_SECRET on the server.",
                            "text/plain; charset=utf-8");
            return;
        }
        const std::string state = noxy::randomHex(16);
        res.headers.emplace("Set-Cookie", makeCookie("noxy_oauth_state", state, 600, secureCookies, "/auth"));
        const std::string url = opt.auth.discordWeb + "/oauth2/authorize?client_id=" + noxy::urlEncode(opt.auth.clientId) +
                                "&response_type=code&scope=identify&redirect_uri=" +
                                noxy::urlEncode(opt.auth.redirectUri()) + "&state=" + state;
        res.set_redirect(url, 302);
    });

    svr.Get("/auth/callback", [&](const httplib::Request& req, httplib::Response& res) {
        // The state cookie is single use. Clear it whatever happens next.
        res.headers.emplace("Set-Cookie", makeCookie("noxy_oauth_state", "", 0, secureCookies, "/auth"));
        if (req.has_param("error")) {
            res.set_redirect("/?login=cancelled", 302);
            return;
        }
        const std::string expected = cookieValue(req, "noxy_oauth_state");
        const std::string got = req.get_param_value("state");
        if (!opt.auth.configured() || expected.empty() || !sameSecret(got, expected)) {
            res.set_redirect("/?login=failed", 302);
            return;
        }
        std::string error;
        auto member = noxy::completeLogin(opt.auth, req.get_param_value("code"), noxy::unixTimeMs(), error);
        if (!member) {
            std::cerr << "[Noxy] Member login failed: " << error << "\n";
            res.set_redirect("/?login=failed", 302);
            return;
        }
        const std::string token = sessions.create(*member);
        res.headers.emplace("Set-Cookie", makeCookie("noxy_session", token, kSessionCookieSeconds, secureCookies, "/"));
        res.set_redirect("/", 302);
    });

    svr.Post("/auth/logout", [&](const httplib::Request& req, httplib::Response& res) {
        const std::string token = cookieValue(req, "noxy_session");
        if (!token.empty()) sessions.erase(token);
        res.headers.emplace("Set-Cookie", makeCookie("noxy_session", "", 0, secureCookies, "/"));
        sendJson(res, 200, {{"ok", true}});
    });

    // ---------- member API (signed-in member only) ----------

    svr.Get("/api/member/me", [&](const httplib::Request& req, httplib::Response& res) {
        const auto member = currentMember(req);
        if (!member) {
            sendJson(res, 401, {{"error", "login_required"}});
            return;
        }
        const auto snap = store.current();
        if (!snap) {
            sendJson(res, 503, {{"error", "Stats are unavailable right now."}});
            return;
        }
        noxy::json profile = noxy::buildMemberProfile(snap->db, member->userId, noxy::unixTimeMs());
        profile["user"] = {{"id", member->userId},
                           {"name", member->username},
                           {"avatarUrl", avatarUrl(member->userId, member->avatar)}};
        profile["dataUpdatedAt"] = snap->source.fileModifiedMs;
        sendJson(res, 200, profile);
    });

    svr.Get("/api/member/leaderboard", [&](const httplib::Request& req, httplib::Response& res) {
        const auto member = currentMember(req);
        if (!member) {
            sendJson(res, 401, {{"error", "login_required"}});
            return;
        }
        const auto snap = store.current();
        if (!snap) {
            sendJson(res, 503, {{"error", "Stats are unavailable right now."}});
            return;
        }
        sendJson(res, 200, noxy::buildMemberLeaderboard(snap->db, req.get_param_value("metric"), member->userId));
    });

    // ---------- member server settings (proxied to the bot) ----------
    // The bot checks Manage Server on every call. This side only checks the member's login,
    // sends the member's own Discord ID, and passes the bot's answer back.
    auto relayBot = [](httplib::Response& res, const noxy::BotApiReply& reply) {
        if (reply.status == 0) {
            sendJson(res, 503, {{"error", "The Noxy bot is not reachable right now."}});
            return;
        }
        noxy::json body;
        try {
            body = noxy::json::parse(reply.body);
        } catch (const std::exception&) {
            sendJson(res, 502, {{"error", "Unexpected answer from the Noxy bot."}});
            return;
        }
        sendJson(res, reply.status, body);
    };

    svr.Get("/api/member/servers", [&](const httplib::Request& req, httplib::Response& res) {
        const auto member = currentMember(req);
        if (!member) {
            sendJson(res, 401, {{"error", "login_required"}});
            return;
        }
        if (!opt.bot.configured()) {
            sendJson(res, 503, {{"error", "Server settings are not connected yet."}});
            return;
        }
        relayBot(res, noxy::callBotApi(opt.bot, "GET", member->userId, "", ""));
    });

    svr.Get(R"(/api/member/servers/(\d{15,25}))", [&](const httplib::Request& req, httplib::Response& res) {
        const auto member = currentMember(req);
        if (!member) {
            sendJson(res, 401, {{"error", "login_required"}});
            return;
        }
        if (!opt.bot.configured()) {
            sendJson(res, 503, {{"error", "Server settings are not connected yet."}});
            return;
        }
        relayBot(res, noxy::callBotApi(opt.bot, "GET", member->userId, req.matches[1].str(), ""));
    });

    svr.Patch(R"(/api/member/servers/(\d{15,25}))", [&](const httplib::Request& req, httplib::Response& res) {
        const auto member = currentMember(req);
        if (!member) {
            sendJson(res, 401, {{"error", "login_required"}});
            return;
        }
        if (!opt.bot.configured()) {
            sendJson(res, 503, {{"error", "Server settings are not connected yet."}});
            return;
        }
        // A cross-site form cannot send application/json, so this also blocks cross-site writes.
        const std::string contentType = req.get_header_value("Content-Type");
        if (contentType.rfind("application/json", 0) != 0) {
            sendJson(res, 415, {{"error", "Send the change as JSON."}});
            return;
        }
        if (req.body.size() > 16 * 1024) {
            sendJson(res, 413, {{"error", "Request too large."}});
            return;
        }
        relayBot(res, noxy::callBotApi(opt.bot, "PATCH", member->userId, req.matches[1].str(), req.body));
    });

    // ---------- staff API (token) ----------

    svr.Get("/api/summary", staffApi([](const noxy::Snapshot& s, const httplib::Request&, bool&) {
                noxy::SourceInfo src = s.source;
                src.nowMs = noxy::unixTimeMs();
                return noxy::buildSummary(s.db, src);
            }));

    svr.Get("/api/guilds", staffApi([](const noxy::Snapshot& s, const httplib::Request&, bool&) {
                return noxy::buildGuildList(s.db);
            }));

    svr.Get(R"(/api/guilds/(\d{1,25}))", staffApi([](const noxy::Snapshot& s, const httplib::Request& req, bool& found) {
                noxy::json detail = noxy::buildGuildDetail(s.db, req.matches[1].str(), noxy::unixTimeMs());
                found = !detail.is_null();
                return detail;
            }));

    svr.Get("/api/economy", staffApi([](const noxy::Snapshot& s, const httplib::Request&, bool&) {
                return noxy::buildEconomy(s.db);
            }));

    svr.set_error_handler([](const httplib::Request& req, httplib::Response& res) {
        // Only fill in a body for API routes that did not already set one.
        if (req.path.rfind("/api/", 0) == 0 && res.body.empty()) {
            sendJson(res, res.status ? res.status : 404, {{"error", "Not found."}});
        }
    });

    // ---------- static UI ----------

    // Static mounts are matched before normal routes, so the bare "/admin" redirect runs before routing.
    svr.set_pre_routing_handler([](const httplib::Request& req, httplib::Response& res) {
        if (req.path == "/admin") {
            res.set_redirect("/admin/", 301);
            return httplib::Server::HandlerResponse::Handled;
        }
        return httplib::Server::HandlerResponse::Unhandled;
    });
    if (!svr.set_mount_point("/admin", (opt.web / "admin").string()) ||
        !svr.set_mount_point("/", (opt.web / "member").string())) {
        std::cerr << "Could not serve the UI folders under " << opt.web.string() << "\n";
        return 1;
    }

    if (generatedToken) {
        std::cout << "  Staff token : " << opt.adminToken << "  (generated for this run; set NOXY_DASHBOARD_TOKEN to keep one)" << std::endl;
    }
    if (!isLoopback(opt.host)) {
        std::cout << "  Note        : listening beyond this machine. Put it behind HTTPS.\n";
    }

    std::cout << "Noxy Dashboard\n"
              << "  Database    : " << opt.db.string()
              << (store.lastError().empty() ? "" : "  (not loaded yet: " + store.lastError() + ")") << "\n"
              << "  Members     : http://" << opt.host << ":" << opt.port << "/\n"
              << "  Staff       : http://" << opt.host << ":" << opt.port << "/admin/ ("
              << (needsAdminToken ? "token required" : "no token, local use only") << ")\n"
              << "  Member login: "
              << (opt.auth.configured() ? "on, redirect " + opt.auth.redirectUri()
                                        : "off (set NOXY_DISCORD_CLIENT_SECRET to enable)")
              << "\nPress Ctrl+C to stop.\n";

    std::cout << "  Server settings: "
              << (opt.bot.configured() ? "on, bot at " + opt.bot.baseUrl : std::string("off (set NOXY_INTERNAL_KEY)")) << std::endl;

    if (!svr.listen(opt.host, opt.port)) {
        std::cerr << "Could not listen on " << opt.host << ":" << opt.port
                  << ". Is the port already in use?\n";
        return 1;
    }
    return 0;
}
