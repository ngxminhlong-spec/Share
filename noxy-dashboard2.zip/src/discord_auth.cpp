// discord_auth.cpp
#include "discord_auth.hpp"
#include "database_store.hpp"

#include <httplib.h>
#include <nlohmann/json.hpp>

#include <cctype>
#include <cstdio>
#include <iterator>
#include <random>

namespace noxy {
namespace {

constexpr std::int64_t kSessionMs = 7LL * 24 * 60 * 60 * 1000;  // one week
constexpr const char* kUserAgent = "NoxyDashboard/1.0";

// Splits "https://host[:port]/path" into parts. Only http and https are accepted.
bool splitUrl(const std::string& url, std::string& scheme, std::string& host, int& port, std::string& path) {
    const auto sep = url.find("://");
    if (sep == std::string::npos) return false;
    scheme = url.substr(0, sep);
    if (scheme != "http" && scheme != "https") return false;
    const auto start = sep + 3;
    const auto slash = url.find('/', start);
    const std::string hostPort = url.substr(start, slash == std::string::npos ? std::string::npos : slash - start);
    path = slash == std::string::npos ? "/" : url.substr(slash);
    const auto colon = hostPort.rfind(':');
    if (colon != std::string::npos) {
        host = hostPort.substr(0, colon);
        port = std::stoi(hostPort.substr(colon + 1));
    } else {
        host = hostPort;
        port = scheme == "https" ? 443 : 80;
    }
    return !host.empty();
}

httplib::Headers baseHeaders() {
    return httplib::Headers{{"User-Agent", kUserAgent}};
}

httplib::Result httpPost(const std::string& url, const httplib::Headers& headers, const std::string& body,
                         const std::string& contentType) {
    std::string scheme, host, path;
    int port = 0;
    if (!splitUrl(url, scheme, host, port, path)) return httplib::Result{nullptr, httplib::Error::Connection};
    if (scheme == "https") {
        httplib::SSLClient cli(host, port);
        cli.set_connection_timeout(10);
        cli.set_read_timeout(10);
        return cli.Post(path, headers, body, contentType);
    }
    httplib::Client cli(host, port);
    cli.set_connection_timeout(10);
    cli.set_read_timeout(10);
    return cli.Post(path, headers, body, contentType);
}

httplib::Result httpGet(const std::string& url, const httplib::Headers& headers) {
    std::string scheme, host, path;
    int port = 0;
    if (!splitUrl(url, scheme, host, port, path)) return httplib::Result{nullptr, httplib::Error::Connection};
    if (scheme == "https") {
        httplib::SSLClient cli(host, port);
        cli.set_connection_timeout(10);
        cli.set_read_timeout(10);
        return cli.Get(path, headers);
    }
    httplib::Client cli(host, port);
    cli.set_connection_timeout(10);
    cli.set_read_timeout(10);
    return cli.Get(path, headers);
}

}  // namespace

std::string randomHex(std::size_t bytes) {
    std::random_device rd;
    static const char* digits = "0123456789abcdef";
    std::string out;
    out.reserve(bytes * 2);
    for (std::size_t i = 0; i < bytes; ++i) {
        const auto b = static_cast<unsigned char>(rd() & 0xFF);
        out.push_back(digits[b >> 4]);
        out.push_back(digits[b & 0x0F]);
    }
    return out;
}

std::string urlEncode(const std::string& value) {
    std::string out;
    for (const unsigned char c : value) {
        if (std::isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~') {
            out.push_back(static_cast<char>(c));
        } else {
            char buf[4];
            std::snprintf(buf, sizeof(buf), "%%%02X", c);
            out += buf;
        }
    }
    return out;
}

std::string SessionStore::create(MemberSession session) {
    const std::string token = randomHex(32);
    std::lock_guard<std::mutex> lock(mutex_);
    // Drop sessions that have expired so the map cannot grow forever.
    const auto now = unixTimeMs();
    for (auto it = sessions_.begin(); it != sessions_.end();) {
        it = it->second.expiresMs <= now ? sessions_.erase(it) : std::next(it);
    }
    sessions_[token] = std::move(session);
    return token;
}

std::optional<MemberSession> SessionStore::find(const std::string& token, std::int64_t nowMs) {
    std::lock_guard<std::mutex> lock(mutex_);
    const auto it = sessions_.find(token);
    if (it == sessions_.end()) return std::nullopt;
    if (it->second.expiresMs <= nowMs) {
        sessions_.erase(it);
        return std::nullopt;
    }
    return it->second;
}

void SessionStore::erase(const std::string& token) {
    std::lock_guard<std::mutex> lock(mutex_);
    sessions_.erase(token);
}

std::optional<MemberSession> completeLogin(const AuthConfig& cfg, const std::string& code, std::int64_t nowMs,
                                           std::string& error) {
    using nlohmann::json;

    // 1. Trade the one-time code for an access token. The client secret is only sent server to server.
    const std::string form = "grant_type=authorization_code&code=" + urlEncode(code) +
                             "&redirect_uri=" + urlEncode(cfg.redirectUri()) +
                             "&client_id=" + urlEncode(cfg.clientId) +
                             "&client_secret=" + urlEncode(cfg.clientSecret);
    auto tokenRes = httpPost(cfg.discordApi + "/oauth2/token", baseHeaders(), form,
                             "application/x-www-form-urlencoded");
    if (!tokenRes) {
        error = "Could not reach Discord.";
        return std::nullopt;
    }
    if (tokenRes->status != 200) {
        error = "Discord rejected the login code.";
        return std::nullopt;
    }
    std::string accessToken;
    try {
        accessToken = json::parse(tokenRes->body).at("access_token").get<std::string>();
    } catch (const std::exception&) {
        error = "Unexpected response from Discord.";
        return std::nullopt;
    }

    // 2. Ask who this is. The "identify" scope only gives the basic profile.
    httplib::Headers auth = baseHeaders();
    auth.emplace("Authorization", "Bearer " + accessToken);
    auto userRes = httpGet(cfg.discordApi + "/users/@me", auth);
    if (!userRes || userRes->status != 200) {
        error = "Could not read the Discord profile.";
        return std::nullopt;
    }
    try {
        const json me = json::parse(userRes->body);
        MemberSession s;
        s.userId = me.at("id").get<std::string>();
        s.username = me.contains("global_name") && me["global_name"].is_string() && !me["global_name"].get<std::string>().empty()
                         ? me["global_name"].get<std::string>()
                         : me.value("username", std::string("member"));
        s.avatar = me.contains("avatar") && me["avatar"].is_string() ? me["avatar"].get<std::string>() : "";
        s.expiresMs = nowMs + kSessionMs;
        return s;
    } catch (const std::exception&) {
        error = "Unexpected profile from Discord.";
        return std::nullopt;
    }
}

}  // namespace noxy
