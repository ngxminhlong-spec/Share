# Vendored dependencies

Both libraries are single-header and MIT-licensed. They are checked in so the
dashboard builds without network access.

| File | Library | Version | SHA-256 |
|------|---------|---------|---------|
| `httplib.h` | cpp-httplib (https://github.com/yhirose/cpp-httplib) | 0.18.3 | `a0a0c13dc086663863dbe6730a19716f7d3744904b6205496e8301750814dbd5` |
| `nlohmann/json.hpp` | nlohmann/json (https://github.com/nlohmann/json) | 3.11.3 | `9bea4c8066ef4a1c206b2be5a36302f8926f7fdc6087af5d20b417d0cf103ea6` |

To update, replace the files with the new release and update this table.
